# test_python_script.py
#from transformers import pipeline
import json

# Run sentiment analysis
#sentiment_pipeline = pipeline('sentiment-analysis')
#data = ['I hate this product', 'I love this product', 'I love using this application']
#result_list = sentiment_pipeline(data)

# Print the result in JSON format
#print(json.dumps(result_list))

#source /home/eya/sentiment-env/bin/activate
#gcc -o test-python-c test-python-c.c -I/usr/include/python3.6 -L/usr/lib/x86_64-linux-gnu -lpython3.6m -ljansson
#./test-python-c



# Initialize an empty list to store the lines
feedback_list = []

try:
    file_name = "/home/eya/Projects/Avis/review.txt"
    # Open the file and read each line
    with open(file_name, "r") as file:
        for line in file:
            # Remove any leading/trailing whitespace, including newlines
            clean_line = line.strip()
            if clean_line:  # Only add non-empty lines
                feedback_list.append(clean_line)
except FileNotFoundError:
    print("error")
except Exception as e:
    print("An error occurred:")

# Output the list
print(feedback_list)

