#include <gtk/gtk.h>


void
on_user_interface_show                 (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_btn_show_profile_data_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_logout_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_cancel_btn_edit_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_apply_btn_edit_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiofemale_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiomale_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_delete_profile_btn_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_print_fact_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_update_btn_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_togglebutton2_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_togglebutton1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_reserv_btn_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_feedback_btn_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_helpbutton1_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_cancelbutton1_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbutton1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_cancelbutton2_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_cancelbutton3_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbutton3_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_signinbtn_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_backaddtologin_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_sinupbtn_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_loginbtn_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_backlogintowelcome_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_clientbtn_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_adminbtn_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
//enaa
void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonfemme_toggled            (GtkToggleButton *femme,
                                        gpointer         user_data);

void
on_radiobuttonhomme_toggled            (GtkToggleButton *homme,
                                        gpointer         user_data);

void
on_buttonenregistrer_clicked           (GtkButton       *confirmer,
                                        gpointer         user_data);

void
on_checkbuttonnonformul_clicked        (GtkButton       *non,
                                        gpointer         user_data);

void
on_checkbuttonouiformul_clicked        (GtkButton       *oui,
                                        gpointer         user_data);

void
on_buttonsupprimer_clicked             (GtkButton       *supprimer,
                                        gpointer         user_data);



void
on_actualiser_clicked                  (GtkButton       *actualiser,
                                        gpointer         user_data);

void
on_buttonquitterequipe_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void supprimer_ligne_treeview(GtkWidget *del);
int obtenir_id_agent_selectionne(GtkTreeView *treeview);

void
on_buttonmodifier_clicked              (GtkButton       *modifier,
   
                                     gpointer         user_data);


void
on_buttonrechercheequipe_clicked       (GtkButton       *rechercher,
                                        gpointer         user_data);

void
on_buttonrechercheres_clicked          (GtkButton       *rechres,
                                        gpointer         user_data);

void
on_actualiserres_clicked               (GtkButton       *actualiser,
                                        gpointer         user_data);


void
on_checkbuttonouimodif_toggled         (GtkToggleButton *ouimodif,
                                        gpointer         user_data);

void
on_checkbuttonnonmodif_toggled         (GtkToggleButton *nonmodif,
                                        gpointer         user_data);

                                    

void
on_buttonsavemodif_clicked             (GtkButton       *save,
                                        gpointer         user_data);

void
on_radiobuttonhommemodif_toggled       (GtkToggleButton *hom,
                                        gpointer         user_data);

void
on_radiobuttonfemmemodif_toggled       (GtkToggleButton *fem,
                                        gpointer         user_data);

void
on_envoyer_clicked                     (GtkButton       *envoyer,
                                        gpointer         user_data);

void
on_buttonsavoirplus_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquitterformul_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquitteres_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_quittercontact_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquittermodif_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquittersavoirplus_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitreview_clicked                  (GtkButton       *button,
                                        gpointer         user_data);


void
on_treeviewequipe_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_combotri_changed                    (GtkComboBox     *combobox,
                                        gpointer         user_data);





/*void
on_radiobuttonhomme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfemme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_radiobuttonhommemodif_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfemmemodif_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);*/

void
on_combosort_changed                   (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_etoile4_toggled                     (GtkToggleButton *quatre,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *cinq,
                                        gpointer         user_data);

void
on_etoile2_toggled                     (GtkToggleButton *deux,
                                        gpointer         user_data);

void
on_etoile3_toggled                     (GtkToggleButton *trois,
                                        gpointer         user_data);

void
on_etoile1_toggled                     (GtkToggleButton *un,
                                        gpointer         user_data);

void
on_autre_toggled                       (GtkToggleButton *autre,
                                        gpointer         user_data);

void
on_service_toggled                     (GtkToggleButton *service,
                                        gpointer         user_data);

void
on_agent_toggled                       (GtkToggleButton *agent,
                                        gpointer         user_data);

void
on_submitavis_clicked                  (GtkButton       *button,
                                        gpointer         user_data);



void
on_actualiseravis_clicked              (GtkButton       *actualiser,
                                        gpointer         user_data);


void
on_quitteravis_clicked                 (GtkButton       *quitter,
                                        gpointer         user_data);

void
on_quitterhistorique_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_combobox_changed                    (GtkComboBox     *combobox,
                                        gpointer         user_data);



void
on_acttrev_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
void
on_stats_clicked                       (GtkButton       *stat,
                                        gpointer         user_data);

//guezguez


typedef struct {
    char nompark[100];
    int idpark;
    char localisationpark[100];
    int capacitepark;
    int nbrdispopark;
    int prixpark;
    char etatpark[50];
    char typepark[50];
    int id_agents;
} Parking;


// Function declarations
void setup_treeview_columns(GtkTreeView *treeview);
void populate_treeview(GtkTreeView *treeview, const char *filename);
void on_btn_aff_clicked(GtkButton *button, gpointer user_data);
void on_btn_ajouterpark_clicked(GtkButton *button, gpointer user_data);
void on_btn_supp_clicked(GtkWidget *widget, gpointer data);
void remove_parking_from_file(const gchar *nompark, int idpark);
void on_btn_search_park_clicked(GtkButton *button, gpointer user_data);
void on_btn_modif_clicked(GtkButton *button, gpointer user_data);
void on_btn_save_modif_clicked(GtkButton *button, gpointer user_data);
void load_agents(const char *filename, GHashTable *parking_agents_map);
void load_parkings_and_agents_for_treeview2(const char *parking_filename, const char *agents_filename, GtkTreeView *treeview);
void setup_treeview_columns_for_treeview2(GtkTreeView *treeview);
void populate_treeview2(GtkTreeView *treeview, const char *filename);
void on_btn_sort_by_id_toggled(GtkToggleButton *togglebutton, gpointer user_data);int compare_parking_by_id(const void *a, const void *b);
void on_btn_sort_by_capacite_toggled(GtkToggleButton *togglebutton, gpointer user_data);int compare_parking_by_capacity(const void *a, const void *b);
void populate_shift_txt_from_parking_and_agents();
void
on_button_assign_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_refreshagent_clicked            (GtkButton       *button,
                                        gpointer         user_data);





void populate_treeview3(GtkTreeView *treeview, const char *filename);
void setup_treeview3_columns(GtkTreeView *treeview);

void
on_btn_aff_agents_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_sort_by_id_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_btn_sort_by_nom_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_btn_sort_by_capacite_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_btn_sort_by_prix_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_btn_visual_clicked                  (GtkButton       *button,
                                        gpointer         user_data);



gboolean update_progress(gpointer data);



//mo3taz




void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);


void
on_radiobutton1_toggled                (GtkToggleButton *NORMAL,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *VIP,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

/*void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);*/




void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);



void
on_treeviewserv_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_homeagent_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_codebar_clicked                     (GtkButton       *button,
                                        gpointer         user_data);




void
on_bar_clicked                         (GtkButton       *button,
                                        gpointer         user_data);
