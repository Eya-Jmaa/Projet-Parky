typedef struct
{
int idagent;
int idparking;
char nom[50];
char prenom[50];
char role[200];
char email[100];
char adresse[200];
int jour;
int mois;
int annee;
int tel;
char exp[20];
char sexe[50];
int cin;
char image[500];
char statut[100];
}Agent;


void ajouter(Agent agent);

void rechercher_agent(GtkTreeView *tree_view, const char *prenom_text, const char *nom_text, int id_recherchepark, const char *role_recherche);
//void rechercher_agent(GtkTreeView *tree_view, const char *prenom_text, const char *nom_text, int id_recherchepark, const char *role_recherche);
void afficher_agents(GtkWidget *tree_view);

typedef struct {
    int idres;
    char nom[100];
    char prenom[100];
    int cin;
    char sexe[100];
    int jour;
    int mois;
    int annee;
} Reservation;

void afficher_res(GtkWidget *tree_view);
int id_existe(int id_modif);
void modifier(Agent agent_modif);
Agent rechercher_agent_par_id(int id_agent);
int get_role_index(const char *role);
void envoyer_email(const char *destinataire, const char *sujet, const char *message);
int comparer_croissant_nom(const void *a, const void *b);
int comparer_decroissant_nom(const void *a, const void *b);
int lire_fichier_agents(const char *nom_fichier, Agent agents[], int taille_max);


