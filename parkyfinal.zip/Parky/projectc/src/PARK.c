
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "PARK.h"

void saisir(Serv *serv) {
    printf("Enter ID Service: ");
    while (scanf("%d", &serv->ID_service) != 1) {
        printf("Invalid input. Please enter an integer: ");
        while (getchar() != '\n'); // Clear invalid input
    }

    printf("Enter Description: ");
    scanf("%s", serv->description);

    printf("Enter Prix: ");
    scanf("%s", serv->Prix);

    printf("Enter Type Service (NORMAL or VIP): ");
    scanf("%s", serv->type_service);

    if (strcmp(serv->type_service, "VIP") == 0) {
        printf("Enter Offre (5%%, 10%%, 15%%): ");
        scanf("%s", serv->offre);
    } else {
        strcpy(serv->offre, "No offer for NORMAL services"); // No offer for NORMAL services
    }
}

void ajouters(Serv serv) {
    FILE *file = fopen(FILENAME, "a");
    if (file == NULL) {
        printf("Error opening file\n");
        return;
    }
    fprintf(file, "%d %s %s %s %s\n",
            serv.ID_service, serv.description, serv.Prix, serv.type_service, serv.offre);
    fclose(file);
}

void modifiers(int id) {
    FILE *file = fopen(FILENAME, "r");
    FILE *temp_file = fopen("Serv_temp.txt", "w");
    if (file == NULL || temp_file == NULL) {
        printf("Error opening file\n");
        return;
    }

    Serv serv;
    int found = 0;

    while (fscanf(file, "%d %99s %9s %9s %9s",
                  &serv.ID_service, serv.description, serv.Prix,
                  serv.type_service, serv.offre) != EOF) {
        if (serv.ID_service == id) {
            found = 1;
            printf("Modifying service with ID %d\n", id);
            saisir(&serv);
        }
        fprintf(temp_file, "%d %s %s %s %s\n",
                serv.ID_service, serv.description, serv.Prix,
                serv.type_service, serv.offre);
    }

    fclose(file);
    fclose(temp_file);

    if (found) {
        remove(FILENAME);
        rename("Serv_temp.txt", FILENAME);
        printf("Service modified successfully\n");
    } else {
        remove("Serv_temp.txt");
        printf("Service not found\n");
    }
}

void supprimers(int id) {
    FILE *file = fopen(FILENAME, "r");
    FILE *temp_file = fopen("Serv_temp.txt", "w");
    if (file == NULL || temp_file == NULL) {
        printf("Error opening file\n");
        return;
    }

    Serv serv;
    int found = 0;

    // Copy all services except the one to delete
    while (fscanf(file, "%d %99s %9s %9s %9s",
                  &serv.ID_service, serv.description, serv.Prix,
                  serv.type_service, serv.offre) != EOF) {
        if (serv.ID_service != id) {
            fprintf(temp_file, "%d %s %s %s %s\n",
                    serv.ID_service, serv.description, serv.Prix,
                    serv.type_service, serv.offre);
        } else {
            found = 1; // Mark that we found the service
        }
    }

    fclose(file);
    fclose(temp_file);

    // Replace the old file with the updated one
    if (found) {
        if (remove(FILENAME) == 0) {
            if (rename("Serv_temp.txt", FILENAME) == 0) {
                printf("Service deleted successfully\n");
            } else {
                printf("Error renaming temporary file\n");
            }
        } else {
            printf("Error deleting the old file\n");
        }
    } else {
        printf("Service not found\n");
        remove("Serv_temp.txt");
    }
}


void recherchers(int id) {
    FILE *file = fopen(FILENAME, "r");
    if (file == NULL) {
        printf("Error opening file\n");
        return;
    }

    Serv serv;
    int found = 0;

    while (fscanf(file, "%d %99s %9s %9s %9s",
                  &serv.ID_service, serv.description, serv.Prix,
                  serv.type_service, serv.offre) != EOF) {
        if (serv.ID_service == id) {
            printf("Service found: ID: %d, Description: %s, Prix: %s, Type: %s, Offre: %s\n",
                   serv.ID_service, serv.description, serv.Prix, serv.type_service, serv.offre);
            found = 1;
            break;
        }
    }

    fclose(file);

    if (!found) {
        printf("Service not found\n");
    }
}

void affichers() {
    FILE *file = fopen(FILENAME, "r");
    if (file == NULL) {
        printf("Error opening file\n");
        return;
    }

    Serv serv;
    while (fscanf(file, "%d %99s %9s %9s %9s",
                  &serv.ID_service, serv.description, serv.Prix,
                  serv.type_service, serv.offre) != EOF) {
        printf("ID: %d, Description: %s, Prix: %s, Type: %s, Offre: %s\n",
               serv.ID_service, serv.description, serv.Prix, serv.type_service, serv.offre);
    }
    fclose(file);
}

