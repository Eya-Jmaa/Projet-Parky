typedef struct 
{
char nom[50];
char prenom[50];
char description[500];
int idavis;
char date[50];
char sujet[50];
int Rate;
}Avis;



int idav();
void obtenirDateActuelle(char *dateActuelle);
void ajouteravis(Avis avis);
void afficher_avis(GtkWidget *tree_view);
//gboolean validate_inputavis(const gchar *input, const gchar *regex, const gchar *error_message);
int comparer_decroissant(const void *a, const void *b);
int comparer_croissant(const void *a, const void *b);

int lire_fichier(const char *nom_fichier, Avis avis[], int taille_max);
void ecrire_fichier(const char *nom_fichier, Avis avis[], int count);


typedef struct {
    GtkProgressBar *progress_bar; // La barre de progression
    int elapsed_steps;            // Nombre d'étapes passées
} ProgressData;

gboolean update_progresss(gpointer user_data);
