#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <curl/curl.h>
#include <stdbool.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "agent.h"
#include "avis.h"
#include <Python.h>
#include <jansson.h>

#include "PARK.h"


#include <gtk/gtkctree.h>

#include "operation.h"

#include <ctype.h>
#define MAX_LINE_LENGTH 256  // Or any appropriate length


char rate[20]="",topic[50]="";
Agent ag;
char Sexe[50]="",ee[20]="";
int id_modif=0;
int logged_in_citizen_id=0;



//enaaaaa

void
on_homeagent_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

  GtkWidget *welcome;
  GtkWidget *Admin;
  welcome = create_welcome ();
  gtk_widget_show (welcome);

// Assuming 'login' is a top-level window
    Admin = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(Admin)) {
        gtk_widget_hide(Admin); // Hide the login window
        g_print("user_interface window is now hidden.\n");
    } else {
        g_warning("The 'user_interface' widget is not a valid window.");
    }

}

void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
 // Charger la fenêtre formulaire depuis l'interface Glade
   GtkWidget *formulaire;
   formulaire = create_formulaire ();
   gtk_widget_show (formulaire);
   GtkWidget *Agent;
// Assuming 'login' is a top-level window
   Agent = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(Agent)) {
        gtk_widget_hide(Agent); // Hide the login window
        g_print("Login window is now hidden.\n");
    } else {
        g_warning("The 'login' widget is not a valid window.");
    }

 

    // Afficher la fenêtre formulaire

}


void
on_radiobuttonfemme_toggled            (GtkToggleButton *femme,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (femme)))
strcpy(Sexe,"female");
}


void
on_radiobuttonhomme_toggled            (GtkToggleButton *homme,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (homme)))
strcpy(Sexe,"male");
}


void
on_buttonenregistrer_clicked           (GtkButton       *confirmer,
                                        gpointer         user_data)
{

Agent a;
char nn[50],id[50];
GtkWidget *entryida,*entryidp,*Mois,*Annee,*output ,*Jour ,*entryadresse,*Num;
GtkWidget *entrynom,*Prenom,*Email,*Role,*Exp,*im,*CIN;
GtkWidget *file_selector,*messagenom,*messageprenom,*messagecin,*messagetel,*messageadresse,*messageemail,*messagesexe,*messagerole;
file_selector = lookup_widget(confirmer, "filechooserbuttonimage");
// Get the profile picture file path from the file selector (if available)
    const gchar *pdp_filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(file_selector));
 if (pdp_filename != NULL) {
        strcpy(a.image, pdp_filename);}
else 
strcpy(a.image,"/home/eya/Desktop/agent/pixmaps/man.jpg");
messagesexe=lookup_widget(confirmer,"msgsexe");
messagetel=lookup_widget(confirmer,"msgtel");
messagecin=lookup_widget(confirmer,"msgcin");
messageemail=lookup_widget(confirmer,"msgemail");   
messageadresse=lookup_widget(confirmer,"msgadresse");
messagenom=lookup_widget(confirmer,"msgnom");
messageprenom=lookup_widget(confirmer,"msgprenom");
output=lookup_widget(confirmer,"message");
Annee=lookup_widget(confirmer,"spinbuttonannee");
Mois=lookup_widget(confirmer,"spinbuttonmois");
Jour=lookup_widget(confirmer,"spinbuttonjour");
entrynom=lookup_widget(confirmer,"entrynomformul");
Num=lookup_widget(confirmer,"entrynumtelformul");
Prenom=lookup_widget(confirmer,"entryprenomformul");
entryadresse=lookup_widget(confirmer,"entryadresseformul");
messagerole=lookup_widget(confirmer,"msgrole");
Email=lookup_widget(confirmer,"entryemailformul");
Role=lookup_widget(confirmer,"comborole");
CIN=lookup_widget(confirmer,"entrycin");

if (strlen(gtk_entry_get_text(GTK_ENTRY(CIN))) == 0 || strlen(gtk_entry_get_text(GTK_ENTRY(entryadresse))) == 0 || strlen(gtk_entry_get_text(GTK_ENTRY(Email))) == 0|| strlen(gtk_entry_get_text(GTK_ENTRY(entrynom))) == 0 || strlen(gtk_entry_get_text(GTK_ENTRY(Prenom))) == 0) {
        GtkWidget *error_dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(confirmer))),
                                                         GTK_DIALOG_DESTROY_WITH_PARENT,
                                                         GTK_MESSAGE_ERROR,
                                                         GTK_BUTTONS_OK,
                                                         "All fileds are required !");
        gtk_dialog_run(GTK_DIALOG(error_dialog));
        gtk_widget_destroy(error_dialog);
        return;
    }


strcpy(id, gtk_entry_get_text(GTK_ENTRY(CIN)));
strcpy(nn, gtk_entry_get_text(GTK_ENTRY(Num)));

strcpy(a.nom, gtk_entry_get_text(GTK_ENTRY(entrynom)));
strcpy(a.prenom, gtk_entry_get_text(GTK_ENTRY(Prenom)));

strcpy(a.email, gtk_entry_get_text(GTK_ENTRY(Email)));
strcpy(a.adresse, gtk_entry_get_text(GTK_ENTRY(entryadresse)));
strcpy(a.role,"vide");
strcpy(a.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Role)));
a.cin=atoi(id);
a.tel=atoi(nn);
a.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Annee));
a.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Mois));
a.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(Jour));

strcpy(a.sexe,Sexe);
strcpy(a.exp,ee);
//if (a.image[0] == '\0') {
    //    strcpy(a.image,"/home/eya/Desktop/agent/pixmaps/contact.png");}
int x=0;
if (!validate_input(a.nom, "^[A-Za-zÀ-ÖØ-öø-ÿ]+(?: [A-Za-zÀ-ÖØ-öø-ÿ]+)*$", "Invalid Name (Letters Only!)")) {
   gtk_label_set_markup(GTK_LABEL(messagenom), "<span foreground='DARKRED'font='12'>Invalid Name (Letters Only!)</span>");

x++;}
else
gtk_label_set_text(GTK_LABEL(messagenom),"" );
if (!validate_input(a.prenom, "^[A-Za-zÀ-ÖØ-öø-ÿ]+(?: [A-Za-zÀ-ÖØ-öø-ÿ]+)*$", "Invalid Surname (Letters Only!)")) {
   gtk_label_set_markup(GTK_LABEL(messageprenom), "<span foreground='DARKRED'font='12'>Invalid Surname (Letters Only!)</span>");

x++;}
else
gtk_label_set_text(GTK_LABEL(messageprenom),"" );
if (!validate_input(a.email, "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$", "Invalid Email ! (exple: X@Y.Z)")) {
   gtk_label_set_markup(GTK_LABEL(messageemail), "<span foreground='DARKRED'font='12'>Invalid Email ! (exple: X@Y.Z).</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(messageemail),"" );
if (!validate_input(id,"^\\d{8}$", " CIN invalide ! (8 chiffres!)")) {
gtk_label_set_markup(GTK_LABEL(messagecin), "<span foreground='DARKRED'font='12'>Invalid CIN ! (exactly 8 numbers !)</span>");

x++;}
else
gtk_label_set_text(GTK_LABEL(messagecin),"" );
if (!validate_input(nn,"^\\d{8}$", "Numéro invalide ! (8 chiffres!).")) {
  gtk_label_set_markup(GTK_LABEL(messagetel), "<span foreground='DARKRED'font='12'>Invalid phone number ! ( exactly 8 numbers!).</span>"); 
x++;}
else
gtk_label_set_text(GTK_LABEL(messagetel),"" );
if (!validate_input(a.adresse,"^[A-Za-z0-9À-ÖØ-öø-ÿ,.-]+$", "Invlalid Adress (no special caracters allowed !)")) {
  gtk_label_set_markup(GTK_LABEL(messageadresse), "<span foreground='DARKRED'font='12'>Invlalid Adress (no special caracters allowed !)</span>"); 

x++;}
else
gtk_label_set_text(GTK_LABEL(messageadresse),"" );
if (strcmp(a.sexe,"")==0)
  { gtk_label_set_markup(GTK_LABEL(messagesexe), "<span foreground='DARKRED'font='12'>Activate the button</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(messagesexe),"" );
if(strcmp(a.role,"vide")==0)
{gtk_label_set_markup(GTK_LABEL(messagerole), "<span foreground='DARKRED'font='12'>choose a role</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(messagerole),"" );


if (x>0)
{GtkWidget *errordialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(confirmer))),
                                               GTK_DIALOG_DESTROY_WITH_PARENT,
                                               GTK_MESSAGE_ERROR,
                                               GTK_BUTTONS_OK,
                                               "All inputs must be VALID !");
    gtk_dialog_run(GTK_DIALOG(errordialog));
    gtk_widget_destroy(errordialog);}
else{
ajouter(a);
//gtk_label_set_text(GTK_LABEL(output),"Agent ajouté avec succès !");
 GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(confirmer))),
                                               GTK_DIALOG_DESTROY_WITH_PARENT,
                                               GTK_MESSAGE_INFO,
                                               GTK_BUTTONS_OK,
                                               "Agent added successfully !");
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(confirmer), "entrynomformul")), "");
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(confirmer), "entryprenomformul")), "");
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(confirmer), "entryadresseformul")), "");
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(confirmer), "entryemailformul")), "");
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(confirmer), "entrycin")), "");
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(confirmer), "entrynumtelformul")), "");

    gtk_label_set_text(GTK_LABEL(messageadresse),"" );
    gtk_label_set_text(GTK_LABEL(messageprenom),"" );
    gtk_label_set_text(GTK_LABEL(messagenom),"" );
gtk_label_set_text(GTK_LABEL(messagetel),"" );
gtk_label_set_text(GTK_LABEL(messageemail),"" );
gtk_label_set_text(GTK_LABEL(messagecin),"" );



    // Réinitialiser les radiobuttons (sélectionner le premier ou aucun)
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(lookup_widget(GTK_WIDGET(confirmer), "radiobuttonhomme")), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(lookup_widget(GTK_WIDGET(confirmer), "radiobuttonfemme")), FALSE);

    // Réinitialiser le combobox (désélectionner toute option)
    gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(GTK_WIDGET(confirmer), "comborole")), -1);

    // Désactiver le checkbox (par exemple pour "expérimenté ?")
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(lookup_widget(GTK_WIDGET(confirmer), "checkbuttonnonformul")), FALSE);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(lookup_widget(GTK_WIDGET(confirmer), "checkbuttonouiformul")), FALSE);
    gtk_file_chooser_unselect_all(GTK_FILE_CHOOSER(file_selector));}




}


void
on_checkbuttonnonformul_clicked        (GtkButton       *non,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(non))
strcpy(ee,"no");
}


void
on_checkbuttonouiformul_clicked        (GtkButton       *oui,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(oui))
strcpy(ee,"yes");
}


void
on_buttonsupprimer_clicked             (GtkButton       *supprimer,
                                        gpointer         user_data)
{



GtkTreeView *treeview = GTK_TREE_VIEW(lookup_widget(GTK_WIDGET(supprimer), "treeviewequipe"));
    GtkTreeSelection *selection = gtk_tree_view_get_selection(treeview);
    GtkTreeModel *model;
    GtkTreeIter iter;

    // Vérifier si une ligne est sélectionnée
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        // Récupérer l'ID de l'agent sélectionné
        int id_agent;
        gtk_tree_model_get(model, &iter, 0, &id_agent, -1);

        // Boîte de dialogue de confirmation
        GtkWidget *confirmation_dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(supprimer))),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_YES_NO,
            "The delete is PERMENANT ! Are you sure ? !");
        
        gint response = gtk_dialog_run(GTK_DIALOG(confirmation_dialog));
        gtk_widget_destroy(confirmation_dialog);

        if (response == GTK_RESPONSE_YES) {
            // Suppression de l'agent dans le fichier
            supprimer_ligne_treeview(GTK_WIDGET(supprimer));

            // Suppression de la ligne dans le TreeView
            gtk_list_store_remove(GTK_LIST_STORE(model), &iter);

            // Boîte de dialogue de succès
            GtkWidget *success_dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(supprimer))),
                GTK_DIALOG_DESTROY_WITH_PARENT,
                GTK_MESSAGE_INFO,
                GTK_BUTTONS_OK,
                "Agent deleted successfully !");
            
            gtk_dialog_run(GTK_DIALOG(success_dialog));
            gtk_widget_destroy(success_dialog);
        }
    } else {
        // Si aucune ligne n'est sélectionnée, afficher un message d'erreur
        GtkWidget *error_dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(supprimer))),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "No Agent is selected !");
        
        gtk_dialog_run(GTK_DIALOG(error_dialog));
        gtk_widget_destroy(error_dialog);
    }



}

void
on_actualiser_clicked                  (GtkButton       *actualiser,
                                        gpointer         user_data)
{
//show_tree_view(GTK_WIDGET(actualiser));
g_print("Le bouton Actualiser a été cliqué.\n");
    GtkWidget *tree_view = lookup_widget(GTK_WIDGET(actualiser), "treeviewequipe");

    if (!tree_view) {
        g_print("Erreur : TreeView non trouvé.\n");
        return;
    }
    afficher_agents(tree_view);
    gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(GTK_WIDGET(actualiser), "combotri")), -1);
    gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(GTK_WIDGET(actualiser), "comboroleequipe")), -1);
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(actualiser), "entryidparkingformulaire")), "");
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(actualiser), "entrynomequipe")), "");
gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(actualiser), "entryprenomequipe")), "");
gtk_label_set_text(GTK_LABEL(lookup_widget(GTK_WIDGET(actualiser), "errid")),"" );
gtk_label_set_text(GTK_LABEL(lookup_widget(GTK_WIDGET(actualiser), "errprenom")),"" );
gtk_label_set_text(GTK_LABEL(lookup_widget(GTK_WIDGET(actualiser), "errnom")),"" );
  // Assurer que user_data est bien un TreeView
    

}



void
on_buttonquitterequipe_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{


/*GtkWidget *Agent;

// Assuming 'login' is a top-level window
 Agent = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(Agent)) {
        gtk_widget_destroy(Agent); // Hide the login window
        g_print("fenetre Agent destroyed.\n");
    } else {
        g_warning("The Agent widget is not a valid window.");
    }*/
    gtk_main_quit();
}


void supprimer_ligne_treeview(GtkWidget *del) {
    GtkWidget *tree_view = lookup_widget(del, "treeviewequipe");

    if (!tree_view) {
        g_printerr("Error: TreeView widget not found.\n");
        return;
    }

    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(tree_view));
    GtkTreeModel *model;
    GtkTreeIter iter;

    // Vérifiez si une ligne est sélectionnée
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        // Récupérez l'ID Agent (première colonne)
        int id_agent;
        gtk_tree_model_get(model, &iter, 0, &id_agent, -1);

        // Supprimez l'entrée correspondante dans le fichier
        FILE *file = fopen("agents.txt", "r");
        FILE *temp_file = fopen("temp_agents.txt", "w");

        if (!file || !temp_file) {
            g_printerr("Error opening files.\n");
            if (file) fclose(file);
            if (temp_file) fclose(temp_file);
            return;
        }

        // Copiez toutes les lignes sauf celle avec l'ID correspondant
        char line[1024];
        Agent agent;
        while (fgets(line, sizeof(line), file)) {
            
            sscanf(line, "%d ,", &agent.idagent); // Parsez l'ID Agent

            if (agent.idagent != id_agent) {
                fputs(line, temp_file);
            }
        }

        fclose(file);
        fclose(temp_file);

        // Remplacez l'ancien fichier par le fichier temporaire
        remove("agents.txt");
        rename("temp_agents.txt", "agents.txt");

        // Supprimez la ligne du TreeView
        gtk_list_store_remove(GTK_LIST_STORE(model), &iter);
    } else {
        g_printerr("No row selected.\n");
    }
}

/*int obtenir_id_agent_selectionne(GtkTreeView *treeview) {
    GtkTreeSelection *selection = gtk_tree_view_get_selection(treeview);
    GtkTreeModel *model;
    GtkTreeIter iter;
    int id_agent = -1;

    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        gtk_tree_model_get(model, &iter, 0, &id_agent, -1); // Colonne 0 pour ID Agent
    }

    return id_agent;
}*/


void charger_formulaire_avec_agent(int idagent, GtkWidget *formulaire) {
    // Récupérer les informations de l'agent à partir de l'ID
    Agent agent = rechercher_agent_par_id(idagent);

    if (agent.idagent == -1) {
        g_print("Agent introuvable !");
        return;
    }

    // Widgets du formulaire
    GtkWidget *file_selector = lookup_widget(formulaire, "filechooserbuttonmodif");
    GtkWidget *entrynom = lookup_widget(formulaire, "entrynommodif");
    GtkWidget *Prenom = lookup_widget(formulaire, "entryprenommodif");
    GtkWidget *entryadresse = lookup_widget(formulaire, "entryadressemodif");
    GtkWidget *CIN = lookup_widget(formulaire, "entrycinmodif");
    GtkWidget *Num = lookup_widget(formulaire, "entrytelmodif");

    GtkWidget *Email = lookup_widget(formulaire, "entryemailmodif");
    GtkWidget *Role = lookup_widget(formulaire, "comborolemodif");
    GtkWidget *Annee = lookup_widget(formulaire, "spinbuttonanneemodif");
    GtkWidget *Mois = lookup_widget(formulaire, "spinbuttonmoismodif");
    GtkWidget *Jour = lookup_widget(formulaire, "spinbuttonjourmodif");
    GtkWidget *radiobuttonhomme = lookup_widget(formulaire, "radiobuttonhommemodif");
    GtkWidget *radiobuttonfemme = lookup_widget(formulaire, "radiobuttonfemmemodif");
    GtkWidget *checknon = lookup_widget(formulaire, "checkbuttonnonmodif");
    GtkWidget *checkoui = lookup_widget(formulaire, "checkbuttonouimodif");
    if (strlen(agent.image) > 0) {
    // Set the previously selected file in the file chooser
    gtk_file_chooser_set_filename(GTK_FILE_CHOOSER(file_selector), agent.image);

}
    // Charger les données dans les champs du formulaire
    gtk_entry_set_text(GTK_ENTRY(entrynom), agent.nom);
    gtk_entry_set_text(GTK_ENTRY(Prenom), agent.prenom);
    gtk_entry_set_text(GTK_ENTRY(entryadresse), agent.adresse);
    gtk_entry_set_text(GTK_ENTRY(CIN), g_strdup_printf("%d", agent.cin));
    gtk_entry_set_text(GTK_ENTRY(Num), g_strdup_printf("%d", agent.tel));

    gtk_entry_set_text(GTK_ENTRY(Email), agent.email);
    gtk_combo_box_set_active(GTK_COMBO_BOX(Role), get_role_index(agent.role)); // Trouver l'index du rôle

    gtk_spin_button_set_value(GTK_SPIN_BUTTON(Annee), agent.annee);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(Mois), agent.mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(Jour), agent.jour);

    if (strcmp(agent.sexe,"male") == 0) {
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radiobuttonhomme), TRUE);
    } else if (strcmp(agent.sexe, "female") == 0) {
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radiobuttonfemme), TRUE);
    }

if (strcmp(agent.exp, "yes") == 0) {
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checkoui), TRUE);
    } else 
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(checknon), TRUE);


}

void
on_buttonmodifier_clicked              (GtkButton       *modifier,
                                        gpointer
         user_data)
{
GtkWidget *formulairemodif;
formulairemodif = create_formulairemodif ();


 GtkTreeView *treeview = GTK_TREE_VIEW(lookup_widget(GTK_WIDGET(modifier), "treeviewequipe"));
    GtkTreeSelection *selection = gtk_tree_view_get_selection(treeview);
    GtkTreeModel *model;
    GtkTreeIter iter;

    // Vérifier si une ligne est sélectionnée
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        int id_agent;
        gtk_tree_model_get(model, &iter, 0, &id_agent, -1);  // ID Agent dans la première colonne
        ag=rechercher_agent_par_id(id_agent);
        // Charger les informations de l'agent et ouvrir le formulaire
        
          // Afficher le formulaire
        charger_formulaire_avec_agent(id_agent, formulairemodif);  // Charger les données dans le formulaire
        gtk_widget_show (formulairemodif);
        GtkWidget *Agent;

// Assuming 'login' is a top-level window
 Agent = gtk_widget_get_toplevel(GTK_WIDGET(modifier));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(Agent)) {
        gtk_widget_hide(Agent); // Hide the login window
        g_print("Login window is now hidden.\n");
    } else {
        g_warning("The 'login' widget is not a valid window.");
    }
    } else {
        // Si aucune ligne n'est sélectionnée, afficher un message d'erreur
        GtkWidget *error_dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(modifier))),
                                                         GTK_DIALOG_DESTROY_WITH_PARENT,
                                                         GTK_MESSAGE_ERROR,
                                                         GTK_BUTTONS_OK,
                                                         "No Agent is selected !");
        gtk_dialog_run(GTK_DIALOG(error_dialog));
        gtk_widget_destroy(error_dialog);
    }


}


void
on_buttonrechercheequipe_clicked       (GtkButton       *rechercher,
                                        gpointer         user_data)
{
    /*GtkWidget *entry_prenom = lookup_widget(rechercher, "entryprenomequipe");
    GtkWidget *entry_nom = lookup_widget(rechercher, "entrynomequipe");
        GtkWidget *entry_idpark = lookup_widget(rechercher, "entryidparkingformulaire");
    GtkWidget *tree_view = lookup_widget(rechercher, "treeviewequipe");
    GtkWidget *Roleeq = lookup_widget(rechercher, "comboroleequipe");

    // Récupérer l'ID depuis l'entrée utilisateur
    const char *prenom_text = gtk_entry_get_text(GTK_ENTRY(entry_prenom));
    const char *nom_text = gtk_entry_get_text(GTK_ENTRY(entry_nom));
      const char *role_text = gtk_combo_box_get_active_text(GTK_COMBO_BOX(Roleeq));
    const char *id_textpark = gtk_entry_get_text(GTK_ENTRY(entry_idpark));
    
    int id_recherchepark = atoi(id_textpark);

    if ( id_recherchepark > 0  || strcmp(nom_text, "") !=0 || strcmp(prenom_text, "") !=0 || strcmp(role_text,"")) {
        // Appeler la fonction de recherche dans agent.c
        rechercher_agent(GTK_TREE_VIEW(tree_view),prenom_text,nom_text ,id_recherchepark,role_text);
    } else {
        g_printerr("Le champs est vide.\n");
    }
}*/
    GtkWidget *ernom = lookup_widget(rechercher, "errnom");
    GtkWidget *erid = lookup_widget(rechercher, "errid");
    GtkWidget *erprenom = lookup_widget(rechercher, "errprenom");
    GtkWidget *entry_prenom = lookup_widget(rechercher, "entryprenomequipe");
    GtkWidget *entry_nom = lookup_widget(rechercher, "entrynomequipe");
    GtkWidget *entry_idpark = lookup_widget(rechercher, "entryidparkingformulaire");
    GtkWidget *tree_view = lookup_widget(rechercher, "treeviewequipe");
    GtkWidget *Roleeq = lookup_widget(rechercher, "comboroleequipe");

    // Récupérer les entrées utilisateur
    const char *prenom_text = gtk_entry_get_text(GTK_ENTRY(entry_prenom));
    const char *nom_text = gtk_entry_get_text(GTK_ENTRY(entry_nom));
    const char *id_textpark = gtk_entry_get_text(GTK_ENTRY(entry_idpark));

    // Obtenir le texte actif du combo box
    const char *role_text = gtk_combo_box_get_active_text(GTK_COMBO_BOX(Roleeq));
    if (role_text == NULL) {
        role_text = ""; // Si aucun rôle sélectionné, utiliser une chaîne vide
    }

    int id_recherchepark = atoi(id_textpark); // Convertir en entier (0 si vide)
if (!validate_input(nom_text, "^([A-Za-zÀ-ÖØ-öø-ÿ]+(?: [A-Za-zÀ-ÖØ-öø-ÿ]+)*)?$", "Nom invalide"))
   gtk_label_set_markup(GTK_LABEL(ernom), "<span foreground='DARKRED'font='12'>Invalid Name </span>");
else
gtk_label_set_text(GTK_LABEL(ernom),"" );

if (!validate_input(prenom_text, "^([A-Za-zÀ-ÖØ-öø-ÿ]+(?: [A-Za-zÀ-ÖØ-öø-ÿ]+)*)?$", "Prénmom invalide "))
   gtk_label_set_markup(GTK_LABEL(erprenom), "<span foreground='DARKRED'font='12'>Invalid Surname </span>");
else
gtk_label_set_text(GTK_LABEL(erprenom),"" );
if (!validate_input(id_textpark, "^\\d*$", "ID Parking invalide ")) 
   gtk_label_set_markup(GTK_LABEL(erid), "<span foreground='DARKRED'font='12'>Invalid ID-Parking </span>");
else
gtk_label_set_text(GTK_LABEL(erid),"" );

    if (id_recherchepark > 0 || strcmp(nom_text, "") != 0 || strcmp(prenom_text, "") != 0 || strcmp(role_text, "") != 0) {
        // Appeler la fonction de recherche
        rechercher_agent(GTK_TREE_VIEW(tree_view), prenom_text, nom_text, id_recherchepark, role_text);
    } else {
        //g_printerr("Veuillez remplir au moins un champ pour la recherche.\n");
GtkWidget *error_dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(rechercher))),
                                                         GTK_DIALOG_DESTROY_WITH_PARENT,
                                                         GTK_MESSAGE_ERROR,
                                                         GTK_BUTTONS_OK,
                                                         "Please fill in at least one field !");
        gtk_dialog_run(GTK_DIALOG(error_dialog));
        gtk_widget_destroy(error_dialog);
        return;
    }
}



void
on_buttonrechercheres_clicked          (GtkButton       *rechres,
                                        gpointer         user_data)
{
 GtkSpinButton *spin_jour = GTK_SPIN_BUTTON(lookup_widget(GTK_WIDGET(rechres), "spinbuttonj"));
    GtkSpinButton *spin_mois = GTK_SPIN_BUTTON(lookup_widget(GTK_WIDGET(rechres), "spinbuttonm"));
    GtkSpinButton *spin_annee = GTK_SPIN_BUTTON(lookup_widget(GTK_WIDGET(rechres), "spinbuttona"));

    int jour = gtk_spin_button_get_value_as_int(spin_jour);
    int mois = gtk_spin_button_get_value_as_int(spin_mois);
    int annee = gtk_spin_button_get_value_as_int(spin_annee);

    // Filter and load matching reservations
    GtkWidget *tree_view = lookup_widget(GTK_WIDGET(rechres), "treeviewres");

    if (!tree_view) {
        g_printerr("Error: TreeView widget not found.\n");
        return;
    }

    GtkListStore *store = gtk_list_store_new(8, 
                                             G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, 
                                             G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);

    FILE *file = fopen("res.txt", "r");
    if (!file) {
        g_printerr("Error: Could not open reservations.txt.\n");
        return;
    }

    Reservation res;
    while (fscanf(file, "%d %99s %99s %d %99s %d-%d-%d",
                  &res.idres, res.nom, res.prenom, &res.cin, res.sexe, 
                  &res.jour, &res.mois, &res.annee) == 8) {
        if (res.jour == jour && res.mois == mois && res.annee == annee) {
            GtkTreeIter iter;
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                               0, res.idres,
                               1, res.nom,
                               2, res.prenom,
                               3, res.cin,
                               4, res.sexe,
                               5, res.jour,
                               6, res.mois,
                               7, res.annee,
                               -1);
        }
    }
    fclose(file);

    gtk_tree_view_set_model(GTK_TREE_VIEW(tree_view), GTK_TREE_MODEL(store));
    g_object_unref(store);
}


void
on_actualiserres_clicked               (GtkButton       *actualiser,
                                        gpointer         user_data)
{


    g_print("Le bouton Actualiser a été cliqué.\n");
    GtkWidget *tree_view = lookup_widget(GTK_WIDGET(actualiser), "treeviewres");

    if (!tree_view) {
        g_print("Erreur : TreeView non trouvé.\n");
        return;
    }
    afficher_res(tree_view);
}




void
on_checkbuttonouimodif_toggled         (GtkToggleButton *ouimodif,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(ouimodif))
strcpy(ee,"yes");
}


void
on_checkbuttonnonmodif_toggled         (GtkToggleButton *nonmodif,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(nonmodif))
strcpy(ee,"no");
}


void
on_radiobuttonhommemodif_toggled       (GtkToggleButton *hom,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (hom)))
strcpy(Sexe,"male");

}


void
on_radiobuttonfemmemodif_toggled       (GtkToggleButton *fem,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (fem)))
strcpy(Sexe,"female");
}

void
on_buttonsavemodif_clicked             (GtkButton       *save,
                                        gpointer         user_data)
{

GtkWidget *file_selector,*messagenom,*messageprenom,*messageadresse,*messagecin,*messagetel,*messageemail,*messagerole;
file_selector = lookup_widget(save, "filechooserbuttonmodif");
// Get the profile picture file path from the file selector (if available)
messagetel=lookup_widget(save,"msgtelmodif");

messagerole=lookup_widget(save,"msgrolemodif");
messagecin=lookup_widget(save,"msgcinmodif");
messageemail=lookup_widget(save,"msgemailmodif");   
messageadresse=lookup_widget(save,"msgadressemodif");
messagenom=lookup_widget(save,"msgnommodif");
messageprenom=lookup_widget(save,"msgprenommodif"); 
GtkWidget *checkoui = lookup_widget(save, "checkbuttonouimodif");
GtkWidget *checknon = lookup_widget(save, "checkbuttonnonmodif");
GtkWidget *SexeHomme = lookup_widget(save, "radiobuttonhommemodif");
    GtkWidget *SexeFemme = lookup_widget(save, "radiobuttonfemmemodif");
    
//GtkWidget *entryida = lookup_widget(save, "entryidagentmodif");
    GtkWidget *entrynom = lookup_widget(save, "entrynommodif");
    GtkWidget *Prenom = lookup_widget(save, "entryprenommodif");
    GtkWidget *entryadresse = lookup_widget(save, "entryadressemodif");
    GtkWidget *CIN = lookup_widget(save, "entrycinmodif");
    GtkWidget *Num = lookup_widget(save, "entrytelmodif");
    GtkWidget *messagesexe = lookup_widget(save, "msgsexemodif");

    GtkWidget *Email = lookup_widget(save, "entryemailmodif");
    GtkWidget *Role = lookup_widget(save, "comborolemodif");
    GtkWidget *Annee = lookup_widget(save, "spinbuttonanneemodif");
    GtkWidget *Mois = lookup_widget(save, "spinbuttonmoismodif");
    GtkWidget *Jour = lookup_widget(save, "spinbuttonjourmodif");
    const gchar *pdp_filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(file_selector));
 if (pdp_filename != NULL) {
         strcpy(ag.image, pdp_filename);

    }

    // Mise à jour des champs non vides
    if (strlen(gtk_entry_get_text(GTK_ENTRY(CIN))) > 0)
        ag.cin = atoi(gtk_entry_get_text(GTK_ENTRY(CIN)));

    if (strlen(gtk_entry_get_text(GTK_ENTRY(entrynom))) > 0)
        strcpy(ag.nom, gtk_entry_get_text(GTK_ENTRY(entrynom)));

    if (strlen(gtk_entry_get_text(GTK_ENTRY(Prenom))) > 0)
        strcpy(ag.prenom, gtk_entry_get_text(GTK_ENTRY(Prenom)));

    if (strlen(gtk_entry_get_text(GTK_ENTRY(entryadresse))) > 0)
        strcpy(ag.adresse, gtk_entry_get_text(GTK_ENTRY(entryadresse)));

    if (strlen(gtk_entry_get_text(GTK_ENTRY(Email))) > 0)
        strcpy(ag.email, gtk_entry_get_text(GTK_ENTRY(Email)));

    

    if (strlen(gtk_entry_get_text(GTK_ENTRY(Num))) > 0)
        ag.tel = atoi(gtk_entry_get_text(GTK_ENTRY(Num)));

    

    if (gtk_combo_box_get_active_text(GTK_COMBO_BOX(Role)) != NULL)
        strcpy(ag.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(Role)));

    // Mise à jour de la date si les valeurs sont définies
    int annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));
    int mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
    int jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
    if (annee > 0 && mois > 0 && jour > 0) {
        ag.annee = annee;
        ag.mois = mois;
        ag.jour = jour;
    }
 if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(SexeHomme))) {
        strcpy(ag.sexe, "male");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(SexeFemme))) {
        strcpy(ag.sexe, "female");
    }


    // Gestion de la checkbox pour "Expérimenté"
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checkoui))) {
        strcpy(ag.exp, "oui");
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(checknon))) {
        strcpy(ag.exp, "non");
    }

    //strcpy(agent.sexe,Sexe);
    //strcpy(agent.exp,ee);
    // Modification dans le fichier

int x=0;
if (!validate_input(ag.nom, "^[A-Za-zÀ-ÖØ-öø-ÿ]+(?: [A-Za-zÀ-ÖØ-öø-ÿ]+)*$", "Invalid Name (Letters Only !)")) {
   gtk_label_set_markup(GTK_LABEL(messagenom), "<span foreground='DARKRED'font='12'>Invalid Name(Letters Only !)</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(messagenom),"" );
if (!validate_input(ag.prenom, "^[A-Za-zÀ-ÖØ-öø-ÿ]+(?: [A-Za-zÀ-ÖØ-öø-ÿ]+)*$", "Prénmom invalide (Que des lettres sont permises!)")) {
   gtk_label_set_markup(GTK_LABEL(messageprenom), "<span foreground='DARKRED'font='12'>Invalid Surname (Letters Only!)</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(messageprenom),"" );
if (!validate_input(ag.email, "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$", "Email invalide ! (exple: X@Y.Z)")) {
   gtk_label_set_markup(GTK_LABEL(messageemail), "<span foreground='DARKRED'font='12'>Invalid Email ! (exple: X@Y.Z).</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(messageemail),"" );
if (!validate_input(gtk_entry_get_text(GTK_ENTRY(CIN)),"^\\d{8}$", " CIN invalide ! (8 chiffres!)")) {
gtk_label_set_markup(GTK_LABEL(messagecin), "<span foreground='DARKRED'font='12'>Invalid CIN ! (Exactly 8 numbers !)</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(messagecin),"" );
if (!validate_input(gtk_entry_get_text(GTK_ENTRY(Num)),"^\\d{8}$", "Numéro invalide ! (8 chiffres!).")) {
  gtk_label_set_markup(GTK_LABEL(messagetel), "<span foreground='DARKRED'font='12'>Invalid Number ! (Exactly 8 numbers !).</span>"); 
x++;}
else
gtk_label_set_text(GTK_LABEL(messagetel),"" );
if (!validate_input(ag.adresse,"^[A-Za-z0-9À-ÖØ-öø-ÿ,.-]+$", "Adresse invalide!(pas de caracteres speciaux !)")) {
  gtk_label_set_markup(GTK_LABEL(messageadresse), "<span foreground='DARKRED'font='12'>Invalid Adress !(No special caracters allowed !)</span>"); 
x++;}
else
gtk_label_set_text(GTK_LABEL(messageadresse),"" );
if (strcmp(ag.sexe,"")==0)
   {gtk_label_set_markup(GTK_LABEL(messagesexe), "<span foreground='DARKRED'font='12'>Activez le bouton</span>");
x++;}
if (strcmp(ag.sexe,"")==0)
  { gtk_label_set_markup(GTK_LABEL(messagesexe), "<span foreground='DARKRED'font='12'>Activate the button</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(messagesexe),"" );
if(strcmp(ag.role,"")==0)
{gtk_label_set_markup(GTK_LABEL(messagerole), "<span foreground='DARKRED'font='12'>Choose a role</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(messagerole),"" );
if (x>0)
{GtkWidget *errordialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(save))),
                                               GTK_DIALOG_DESTROY_WITH_PARENT,
                                               GTK_MESSAGE_ERROR,
                                               GTK_BUTTONS_OK,
                                               "All inputs must be VALID !!");
    gtk_dialog_run(GTK_DIALOG(errordialog));
    gtk_widget_destroy(errordialog);}
else{
    modifier(ag);

    // Affichage d'une confirmation
    GtkWidget *confirmation_dialog = gtk_message_dialog_new(GTK_WINDOW(user_data),
                                                           GTK_DIALOG_DESTROY_WITH_PARENT,
                                                           GTK_MESSAGE_INFO,
                                                           GTK_BUTTONS_OK,
                                                           "Agent successfully modified !");
    gtk_dialog_run(GTK_DIALOG(confirmation_dialog));
    gtk_widget_destroy(confirmation_dialog);}
}

void
on_envoyer_clicked                     (GtkButton       *envoyer,
                                        gpointer         user_data)
{
 // Récupérer les widgets associés
    GtkWidget *entry_destinataire = lookup_widget(GTK_WIDGET(envoyer), "entryemail");
    GtkWidget *entry_sujet = lookup_widget(GTK_WIDGET(envoyer), "entrysujet");
    GtkWidget *textview_message = lookup_widget(GTK_WIDGET(envoyer), "contenu");
    GtkWidget *mess = lookup_widget(GTK_WIDGET(envoyer), "output");

    // Variables pour stocker les données
    const char *destinataire = gtk_entry_get_text(GTK_ENTRY(entry_destinataire));
    const char *sujet = gtk_entry_get_text(GTK_ENTRY(entry_sujet));
    
    GtkTextBuffer *buffer_message = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview_message));
    GtkTextIter start, end;
    gtk_text_buffer_get_bounds(buffer_message, &start, &end);
    char *message = gtk_text_buffer_get_text(buffer_message, &start, &end, FALSE);

    // Vérifier les champs obligatoires
    if (strlen(destinataire) == 0 || strlen(sujet) == 0 || strlen(message) == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(envoyer))),
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "All field are required !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        g_free(message);
        return;
    }

    // Envoyer l'e-mail
int x=0;

if (!validate_input(destinataire, "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$", "Invalid Email ! (exple: X@Y.Z)")) {
   gtk_label_set_markup(GTK_LABEL(mess), "<span foreground='DARKRED'font='12'>Invalid Email ! (exple: X@Y.Z).</span>");
x=1;}
if (x==0)

 { envoyer_email(destinataire, sujet, message);
        gtk_label_set_text(GTK_LABEL(mess), "");

gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(envoyer), "entryemail")), "");
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(envoyer), "entrysujet")), "");
gtk_text_buffer_set_text(buffer_message, "", -1);


    // Afficher un message de confirmation
    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(envoyer))),
                                               GTK_DIALOG_DESTROY_WITH_PARENT,
                                               GTK_MESSAGE_INFO,
                                               GTK_BUTTONS_OK,
                                               "E-mail sent successfully to %s !",destinataire);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);

    // Libérer les ressources
    g_free(message);
}
}

void
on_buttonquitterformul_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Admin;
Admin = create_Admin ();
GtkWidget *tree_view = lookup_widget(GTK_WIDGET(Admin), "treeviewequipe");

    if (!tree_view) {
        g_print("Erreur : TreeView non trouvé.\n");
        return;
    }
    afficher_agents(tree_view);
gtk_widget_show (Admin);

GtkWidget *formulaire;

// Assuming 'login' is a top-level window
 formulaire = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(formulaire)) {
        gtk_widget_destroy(formulaire); // Hide the login window
        g_print("formulaire window is now hidden.\n");
    } else {
        g_warning(" 'formulaire' widget is not a valid window.");
    }

}


void
on_buttonquitteres_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
/*GtkWidget *Agent;

// Assuming 'login' is a top-level window
 Agent = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(Agent)) {
        gtk_widget_destroy(Agent); // Hide the login window
       g_print("fenetre Agent destroyed.\n");
    } else {
        g_warning("The Agent widget is not a valid window.");
    }*/
    gtk_main_quit();

}


void
on_quittercontact_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
/*GtkWidget *Agent;

// Assuming 'login' is a top-level window
 Agent = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(Agent)) {
        gtk_widget_destroy(Agent); // Hide the login window
        g_print("fenetre Agent destroyed.\n");
    } else {
        g_warning("The Agent widget is not a valid window.");
    }*/

    gtk_main_quit();
}


void
on_buttonquittermodif_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Admin;
Admin = create_Admin ();
GtkWidget *tree_view = lookup_widget(GTK_WIDGET(Admin), "treeviewequipe");

    if (!tree_view) {
        g_print("Erreur : TreeView non trouvé.\n");
        return;
    }
    afficher_agents(tree_view);
gtk_widget_show (Admin);

GtkWidget *formulairemodif;

// Assuming 'login' is a top-level window
 formulairemodif = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(formulairemodif)) {
        gtk_widget_destroy(formulairemodif); // Hide the login window
        g_print("formulaire window is now hidden.\n");
    } else {
        g_warning(" 'formulaire' widget is not a valid window.");
    }

}


void
on_buttonquittersavoirplus_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *savoirplus_;

// Assuming 'login' is a top-level window
 savoirplus_ = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(savoirplus_)) {
        gtk_widget_destroy(savoirplus_); // Hide the login window
        g_print("formulaire window is now hidden.\n");
    } else {
        g_warning(" 'formulaire' widget is not a valid window.");
    }

}



void
on_quitreview_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
    gtk_main_quit();
}


void
on_treeviewequipe_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
 GtkTreeModel *model;
    GtkTreeIter iter;

    // Obtenir le modèle et l'itérateur pour la ligne sélectionnée
    model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter, path)) {
        // Récupérer l'ID Agent depuis la ligne sélectionnée
        int id_agent;
        gtk_tree_model_get(model, &iter, 0, &id_agent, -1);

        // Rechercher les informations dans le fichier
        FILE *file = fopen("agents.txt", "r");
        if (!file) {
            g_print("Erreur : impossible d'ouvrir le fichier agents.txt\n");
            return;
        }
        ag=rechercher_agent_par_id(id_agent);
  

        // Afficher la fenêtre savoirplus
        GtkWidget *savoirplus = create_savoirplus_(); // Fonction générée par Glade
        gtk_widget_show(savoirplus);

        // Remplir les labels avec les informations
        GtkWidget *label_nom = lookup_widget(savoirplus, "nom");
        GtkWidget *label_prenom = lookup_widget(savoirplus, "prenom");
        GtkWidget *label_cin = lookup_widget(savoirplus, "cin");
        GtkWidget *label_sexe = lookup_widget(savoirplus, "sexe");
        GtkWidget *label_adresse = lookup_widget(savoirplus, "adresse");
        GtkWidget *label_email = lookup_widget(savoirplus, "email");
        GtkWidget *label_role = lookup_widget(savoirplus, "role");

        GtkWidget *label_id_parking = lookup_widget(savoirplus, "idparking");
        GtkWidget *label_date = lookup_widget(savoirplus, "datenaiss");
        GtkWidget *label_idagent = lookup_widget(savoirplus, "idagent");
        GtkWidget *label_tel = lookup_widget(savoirplus, "numtel");
        GtkWidget *label_exp = lookup_widget(savoirplus, "exp");
        GtkWidget *label_statut = lookup_widget(savoirplus, "label210");
        
        GtkWidget *image_widget;
        image_widget = lookup_widget(savoirplus, "pdp");
        if (ag.image[0] != '\0') {
        gtk_image_set_from_file(GTK_IMAGE(image_widget), ag.image);
    }   else {
        // If no profile picture, set a default image
        gtk_image_set_from_stock(GTK_IMAGE(image_widget), GTK_STOCK_MISSING_IMAGE, GTK_ICON_SIZE_DIALOG);
    }


        gtk_label_set_text(GTK_LABEL(label_nom), ag.nom);
        gtk_label_set_text(GTK_LABEL(label_prenom), ag.prenom);

        gchar cin_text[10];
        sprintf(cin_text, "%d", ag.cin);
        gtk_label_set_text(GTK_LABEL(label_cin), cin_text);

        gtk_label_set_text(GTK_LABEL(label_sexe), ag.sexe);
        gtk_label_set_text(GTK_LABEL(label_adresse), ag.adresse);
        gtk_label_set_text(GTK_LABEL(label_email), ag.email);
        gtk_label_set_text(GTK_LABEL(label_role), ag.role);
        gtk_label_set_text(GTK_LABEL(label_statut), ag.statut);

        gtk_label_set_text(GTK_LABEL(label_exp), ag.exp);

        gchar id_parking_text[10];
        sprintf(id_parking_text, "%d", ag.idparking);
        gtk_label_set_text(GTK_LABEL(label_id_parking),id_parking_text);

        gchar date_text[20];
        sprintf(date_text, "%02d/%02d/%04d", ag.jour, ag.mois, ag.annee);
        gtk_label_set_text(GTK_LABEL(label_date), date_text);

        gchar tel_text[15];
        sprintf(tel_text, "%d", ag.tel);
        gtk_label_set_text(GTK_LABEL(label_tel), tel_text);
        gchar id_text[15];
        sprintf(id_text, "%d", ag.idagent);
        gtk_label_set_text(GTK_LABEL(label_idagent), id_text);
    }

}


void
on_combotri_changed                    (GtkComboBox     *combobox,
                                        gpointer         user_data)
{
  if (!GTK_IS_COMBO_BOX(combobox)) {
        printf("Erreur : Ce n'est pas un GtkComboBox.\n");
        return;
    }

    // Récupérer l'indice actif du ComboBox
    int active_index = gtk_combo_box_get_active(combobox);
    if (active_index == -1) {
        printf("Veuillez choisir un ordre de tri.\n");
        return;
    }

    // Lire les agents depuis le fichier
    Agent agents[100];
    int count = lire_fichier_agents("agents.txt", agents, 100);

    if (count == -1) {
        printf("Erreur lors de la lecture du fichier.\n");
        return;
    }

    // Trier selon le choix dans le ComboBox
    if (active_index == 0) {  // Tri croissant
        qsort(agents, count, sizeof(Agent), comparer_croissant_nom);
    } else if (active_index == 1) {  // Tri décroissant
        qsort(agents, count, sizeof(Agent), comparer_decroissant_nom);
    } else {
        printf("Choix de tri invalide.\n");
        return;
    }

    // Mettre à jour le TreeView avec les agents triés
    GtkWidget *tree_view = lookup_widget(GTK_WIDGET(combobox), "treeviewequipe");
    if (!tree_view) {
        g_print("Erreur : TreeView non trouvé.\n");
        return;
    }
    
    // Accéder au modèle du TreeView
    GtkListStore *list_store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(tree_view)));
    gtk_list_store_clear(list_store);  // Vider le modèle avant de réinsérer les données

    // Insérer les agents triés dans le modèle
    for (int i = 0; i < count; i++) {
        GtkTreeIter iter;
        gtk_list_store_append(list_store, &iter);
        gtk_list_store_set(list_store, &iter,
                           0, agents[i].idagent,
                           1, agents[i].nom,
                           2, agents[i].prenom,
                           3, agents[i].adresse,
                           4, agents[i].email,
                           5, agents[i].role,
                           6, agents[i].exp,
                           7, agents[i].statut,
                           8, agents[i].idparking,
                           -1);
    }

    // Affichage dans le terminal pour vérifier le tri
    printf("TreeView trié par nom %s.\n", active_index == 0 ? "croissant" : "décroissant");
}




/*void
on_radiobuttonhomme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobuttonfemme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobuttonhommemodif_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobuttonfemmemodif_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}*/


void
on_combosort_changed                   (GtkComboBox     *combobox,
                                        gpointer         user_data)
{
if (!GTK_IS_COMBO_BOX(combobox)) {
        printf("Erreur : Ce n'est pas un GtkComboBox.\n");
        return;
    }

    // Récupérer l'indice actif
    int active_index = gtk_combo_box_get_active(combobox);
    if (active_index == -1) {
        printf("Veuillez choisir un ordre de tri.\n");
        return;
    }

    // Récupérer le modèle associé au GtkComboBox
    GtkTreeModel *model = gtk_combo_box_get_model(combobox);
    GtkTreeIter iter;

    const char *tri_selection = NULL;

    // Obtenir le texte ou l'ID correspondant à l'élément sélectionné
    if (gtk_tree_model_get_iter_from_string(model, &iter, g_strdup_printf("%d", active_index))) {
        gtk_tree_model_get(model, &iter, 0, &tri_selection, -1);
    }

    if (tri_selection == NULL) {
        printf("Erreur lors de la récupération de l'option sélectionnée.\n");
        return;
    }

    // Lire le fichier
    Avis avis[100];
    int count = lire_fichier("avis.txt", avis, 100);

    if (count == -1) {
        printf("Erreur lors de la lecture du fichier.\n");
        return;
    }

    // Tri selon le choix dans la combo box
    if (strcmp(tri_selection, "Increasing_Rate") == 0) {
        qsort(avis, count, sizeof(Avis), comparer_croissant);
    } else if (strcmp(tri_selection, "Decreasing_Rate") == 0) {
        qsort(avis, count, sizeof(Avis), comparer_decroissant);
    } else {
        printf("Choix de tri invalide.\n");
        g_free((gpointer)tri_selection);
        return;
    }

    // Réécriture dans le fichier
    ecrire_fichier("avis.txt", avis, count);

    // Affichage d'un message dans le terminal
    printf("Fichier trié en ordre %s.\n", tri_selection);

    // Libérer la mémoire
    g_free((gpointer)tri_selection);
g_print("Le bouton Actualiser a été cliqué.\n");
    GtkWidget *tree_view = lookup_widget(GTK_WIDGET(combobox), "treereview");

    if (!tree_view) {
        g_print("Erreur : TreeView non trouvé.\n");
        return;
    }
    afficher_avis(tree_view);
}


void
on_etoile4_toggled                     (GtkToggleButton *quatre,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (quatre)))
strcpy(rate,"4");
}
void
on_radiobutton5_toggled                (GtkToggleButton *cinq,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (cinq)))
strcpy(rate,"5");
}


void
on_etoile2_toggled                     (GtkToggleButton *deux,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (deux)))
strcpy(rate,"2");
}


void
on_etoile3_toggled                     (GtkToggleButton *trois,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (trois)))
strcpy(rate,"3");
}


void
on_etoile1_toggled                     (GtkToggleButton *un,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (un)))
strcpy(rate,"1");
}


void
on_autre_toggled                       (GtkToggleButton *autre,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(autre))

strcpy(topic,"other");

}


void
on_service_toggled                     (GtkToggleButton *service,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(service))
strcpy(topic,"service");
}


void
on_agent_toggled                       (GtkToggleButton *agent,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(agent))
strcpy(topic,"agent");
}


void
on_submitavis_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entrynom, *Prenom, *ernom,*erprenom;
    Avis b;
    char id[50];

    // Récupération des widgets
 ernom = lookup_widget(button, "ernomavis");
    erprenom = lookup_widget(button, "msprenom");
    entrynom = lookup_widget(button, "entrynonavis");
    Prenom = lookup_widget(button, "entryprenomavis");

    GtkWidget *textview_message = lookup_widget(GTK_WIDGET(button), "textviewavis");
    GtkTextBuffer *buffer_message = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview_message));
    GtkTextIter start, end;
    gtk_text_buffer_get_bounds(buffer_message, &start, &end);
    strcpy(b.description, gtk_text_buffer_get_text(buffer_message, &start, &end, FALSE));

    // Vérification des champs

    strcpy(b.nom, gtk_entry_get_text(GTK_ENTRY(entrynom)));
    strcpy(b.prenom, gtk_entry_get_text(GTK_ENTRY(Prenom)));
    strcpy(b.sujet,topic);
int x=0;
if (!validate_input(b.nom, "^[A-Za-zÀ-ÖØ-öø-ÿ]+(?: [A-Za-zÀ-ÖØ-öø-ÿ]+)*$", "Invalid Name (Letters Only !!)")) {
   gtk_label_set_markup(GTK_LABEL(ernom), "<span foreground='DARKRED'font='12'>Invalid Name (Letters Only !!)</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(ernom),"" );
if (!validate_input(b.prenom, "^[A-Za-zÀ-ÖØ-öø-ÿ]+(?: [A-Za-zÀ-ÖØ-öø-ÿ]+)*$", "Invalid Surname (Letters ONLY !!)")) {
   gtk_label_set_markup(GTK_LABEL(erprenom), "<span foreground='DARKRED'font='12'>Invalid Surname (Letteres ONLY !!)</span>");
x++;}
else
gtk_label_set_text(GTK_LABEL(erprenom),"" );


    if ( strlen(b.nom) == 0 || strlen(b.prenom) == 0 || strlen(b.description) == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "All fields are required !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }

    // Remplissage de la structure

   
    obtenirDateActuelle(b.date);

    // Exemple pour "Rate" et "Sujet" (à remplacer par des champs spécifiques de l'interface)
    
    b.Rate =atoi(rate); // Par défaut ou basé sur un widget de sélection
if (x>0)
{GtkWidget *errordialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                               GTK_DIALOG_DESTROY_WITH_PARENT,
                                               GTK_MESSAGE_ERROR,
                                               GTK_BUTTONS_OK,
                                               "All inputs must be VALID !");
    gtk_dialog_run(GTK_DIALOG(errordialog));
    gtk_widget_destroy(errordialog);}
else{
    // Ajout dans le fichier
    ajouteravis(b);

    // Message de succès
    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                               GTK_DIALOG_DESTROY_WITH_PARENT,
                                               GTK_MESSAGE_INFO,
                                               GTK_BUTTONS_OK,
                                               "Review sent successfully ! \n Thank you for evaluating our parking !");
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);



    gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button), "entrynonavis")), "");
    gtk_entry_set_text(GTK_ENTRY(lookup_widget(GTK_WIDGET(button), "entryprenomavis")), "");
GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview_message));
gtk_text_buffer_set_text(buffer, "", -1);  // Set the text to an empty string

gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(lookup_widget(GTK_WIDGET(button), "other")), FALSE);
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(lookup_widget(GTK_WIDGET(button), "service")), FALSE);
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(lookup_widget(GTK_WIDGET(button), "agent")), FALSE);}
}

void
on_actualiseravis_clicked              (GtkButton       *actualiser,
                                        gpointer         user_data)
{
 g_print("Le bouton Actualiser a été cliqué.\n");
    GtkWidget *tree_view = lookup_widget(GTK_WIDGET(actualiser), "treeview");

    if (!tree_view) {
        g_print("Erreur : TreeView non trouvé.\n");
        return;
    }
    afficher_avis(tree_view);
gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(GTK_WIDGET(actualiser), "combobox")), -1);
}





void
on_quitteravis_clicked                 (GtkButton       *quitter,
                                        gpointer         user_data)
{
/*GtkWidget *avis;

// Assuming 'login' is a top-level window
 avis = gtk_widget_get_toplevel(GTK_WIDGET(quitter));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(avis)) {
        gtk_widget_destroy(avis); // Hide the login window
        g_print("fenetre Agent destroyed.\n");
    } else {
        g_warning("The Agent widget is not a valid window.");
    }*/
gtk_main_quit();


}


void
on_quitterhistorique_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
/*GtkWidget *avis;

// Assuming 'login' is a top-level window
 avis = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(avis)) {
        gtk_widget_destroy(avis); // Hide the login window
        g_print("fenetre Agent destroyed.\n");
    } else {
        g_warning("The Agent widget is not a valid window.");
    }*/

}


void
on_combobox_changed                    (GtkComboBox     *combobox,
                                        gpointer         user_data)
{
if (!GTK_IS_COMBO_BOX(combobox)) {
        printf("Erreur : Ce n'est pas un GtkComboBox.\n");
        return;
    }

    // Récupérer l'indice actif
    int active_index = gtk_combo_box_get_active(combobox);
    if (active_index == -1) {
        printf("Veuillez choisir un ordre de tri.\n");
        return;
    }

    // Récupérer le modèle associé au GtkComboBox
    GtkTreeModel *model = gtk_combo_box_get_model(combobox);
    GtkTreeIter iter;

    const char *tri_selection = NULL;

    // Obtenir le texte ou l'ID correspondant à l'élément sélectionné
    if (gtk_tree_model_get_iter_from_string(model, &iter, g_strdup_printf("%d", active_index))) {
        gtk_tree_model_get(model, &iter, 0, &tri_selection, -1);
    }

    if (tri_selection == NULL) {
        printf("Erreur lors de la récupération de l'option sélectionnée.\n");
        return;
    }

    // Lire le fichier
    Avis avis[100];
    int count = lire_fichier("avis.txt", avis, 100);

    if (count == -1) {
        printf("Erreur lors de la lecture du fichier.\n");
        return;
    }

    // Tri selon le choix dans la combo box
    if (strcmp(tri_selection, "Increasing_Rate") == 0) {
        qsort(avis, count, sizeof(Avis), comparer_croissant);
    } else if (strcmp(tri_selection, "Decreasing_Rate") == 0) {
        qsort(avis, count, sizeof(Avis), comparer_decroissant);
    } else {
        printf("Choix de tri invalide.\n");
        g_free((gpointer)tri_selection);
        return;
    }

    // Réécriture dans le fichier
    ecrire_fichier("avis.txt", avis, count);

    // Affichage d'un message dans le terminal
    printf("Fichier trié en ordre %s.\n", tri_selection);

    // Libérer la mémoire
    g_free((gpointer)tri_selection);
g_print("Le bouton Actualiser a été cliqué.\n");
    GtkWidget *tree_view = lookup_widget(GTK_WIDGET(combobox), "treeview");

    if (!tree_view) {
        g_print("Erreur : TreeView non trouvé.\n");
        return;
    }
    afficher_avis(tree_view);


}





void
on_acttrev_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
g_print("Le bouton Actualiser a été cliqué.\n");

    GtkWidget *tree_view = lookup_widget(GTK_WIDGET(button), "treereview");
    if (!tree_view) {
        g_print("Erreur : TreeView non trouvé.\n");
        return;
    }

    afficher_avis(tree_view);

    gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(GTK_WIDGET(button), "combosort")), -1);

 
}

void
on_bar_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{


    /*// Récupère la GtkProgressBar par son ID
    GtkWidget *progress_bar_widget = lookup_widget(Admin, "progressbar");
    if (!progress_bar_widget) {
        g_print("Error: ProgressBar widget not found.\n");
        return;
    }

    GtkProgressBar *progress_bar = GTK_PROGRESS_BAR(progress_bar_widget);

    // Initialise les données pour la progression
    ProgressData *data = g_malloc(sizeof(ProgressData));
    data->progress_bar = progress_bar;
    data->elapsed_steps = 0;

    // Démarre une mise à jour toutes les 100ms
    g_timeout_add(100, update_progresss, data);*/

}

void
on_stats_clicked                       (GtkButton       *stat,
                                        gpointer         user_data)


{

// Récupère la GtkProgressBar par son ID
GtkWidget *Admin = GTK_WIDGET(gtk_widget_get_toplevel(GTK_WIDGET(stat)));
    GtkWidget *progress_bar_widget = lookup_widget(Admin, "progressbar");
    if (!progress_bar_widget) {
        g_print("Error: ProgressBar widget not found.\n");
        return;
    }

    GtkProgressBar *progress_bar = GTK_PROGRESS_BAR(progress_bar_widget);

    // Initialise les données pour la progression
    ProgressData *data = g_malloc(sizeof(ProgressData));
    data->progress_bar = progress_bar;
    data->elapsed_steps = 0;

    // Démarre une mise à jour toutes les 100ms
    g_timeout_add(100, update_progresss, data);






     /*GtkWidget *label_pos = lookup_widget(GTK_WIDGET(stat), "statpos");
    GtkWidget *label_neg = lookup_widget(GTK_WIDGET(stat), "statneg");

    const char *venv_path = "/home/eya/sentiment-env";

    // Initialize the Python interpreter
    Py_Initialize();

    // Add the virtual environment path to sys.path
    char command[1024];
    snprintf(command, sizeof(command),
             "import sys; import os; sys.path.insert(0, os.path.join('%s', 'lib', 'python3.6', 'site-packages'))", venv_path);
    if (PyRun_SimpleString(command) != 0) {
        fprintf(stderr, "Error adding virtual environment to sys.path\n");
        Py_Finalize();
        return;
    }

    // Import necessary libraries
    if (PyRun_SimpleString("from transformers import pipeline\nimport json") != 0) {
        fprintf(stderr, "Error importing Python modules\n");
        Py_Finalize();
        return;
    }

    // Execute the Python sentiment analysis setup
    const char *python_setup_code =
        "sentiment_pipeline = pipeline('sentiment-analysis')\n"
        "feedback_list = []\n"
        "try:\n"
        "    with open('/home/eya/Desktop/Parky/projectc/review.txt', 'r') as file:\n"
        "        feedback_list = [line.strip() for line in file if line.strip()]\n"
        "except Exception as e:\n"
        "    print(f'Error reading file: {e}')\n"
        "data = feedback_list\n"
        "result_list = sentiment_pipeline(data)\n"
        "result_json = json.dumps(result_list)";
    if (PyRun_SimpleString(python_setup_code) != 0) {
        fprintf(stderr, "Error executing Python sentiment analysis\n");
        Py_Finalize();
        return;
    }

    // Retrieve the JSON result from Python
    PyObject *pModule = PyImport_AddModule("__main__");
    PyObject *pGlobals = PyModule_GetDict(pModule);
    PyObject *pValue = PyRun_String("result_json", Py_eval_input, pGlobals, NULL);

    if (!pValue) {
        PyErr_Print();
        Py_Finalize();
        return;
    }

    // Convert the result to a C string
    const char *result_str = PyUnicode_AsUTF8(pValue);
    if (!result_str) {
        fprintf(stderr, "Error converting Python result to string\n");
        Py_XDECREF(pValue);
        Py_Finalize();
        return;
    }

    // Parse the JSON result using Jansson
    json_error_t error;
    json_t *json_result = json_loads(result_str, 0, &error);
    if (!json_result) {
        fprintf(stderr, "Error parsing JSON: %s\n", error.text);
        Py_XDECREF(pValue);
        Py_Finalize();
        return;
    }

    // Process the JSON result
    size_t array_size = json_array_size(json_result);
    int sentiment_array[array_size];
    for (size_t i = 0; i < array_size; i++) {
        json_t *item = json_array_get(json_result, i);
        json_t *label = json_object_get(item, "label");
        if (label && strcmp(json_string_value(label), "POSITIVE") == 0) {
            sentiment_array[i] = 1;
        } else {
            sentiment_array[i] = 0;
        }
    }

    // Calculate statistics
    int count_zeros = 0, count_ones = 0;
    for (size_t i = 0; i < array_size; i++) {
        if (sentiment_array[i] == 0) count_zeros++;
        else count_ones++;
    }
    float percentage_zeros = (count_zeros / (float)array_size) * 100;
    float percentage_ones = (count_ones / (float)array_size) * 100;

    // Display statistics
    char pos_text[50], neg_text[50];
    snprintf(pos_text, sizeof(pos_text), "%.2f%%", percentage_ones);
    snprintf(neg_text, sizeof(neg_text), "%.2f%%", percentage_zeros);
    gtk_label_set_text(GTK_LABEL(label_pos), pos_text);
    gtk_label_set_text(GTK_LABEL(label_neg), neg_text);

    // Clean up
    json_decref(json_result);
    Py_XDECREF(pValue);

    Py_Finalize();*/

//progressbar











//stats
 GtkWidget *label_pos = lookup_widget(GTK_WIDGET(stat), "statpos");
    GtkWidget *label_neg = lookup_widget(GTK_WIDGET(stat), "statneg");

    const char *venv_path = "/home/eya/sentiment-env";

    // Static variable to ensure Python is initialized only once
    static int python_initialized = 0;

    if (!python_initialized) {
        Py_Initialize();

        // Add the virtual environment path to sys.path
        char command[1024];
        snprintf(command, sizeof(command),
                 "import sys; import os; sys.path.insert(0, os.path.join('%s', 'lib', 'python3.6', 'site-packages'))", venv_path);
        if (PyRun_SimpleString(command) != 0) {
            fprintf(stderr, "Error adding virtual environment to sys.path\n");
            Py_Finalize();
            return;
        }

        python_initialized = 1; // Mark Python as initialized
    }

    // Import necessary libraries (can be done multiple times safely)
    if (PyRun_SimpleString("from transformers import pipeline\nimport json") != 0) {
        fprintf(stderr, "Error importing Python modules\n");
        return;
    }

    // Execute the Python sentiment analysis setup
    const char *python_setup_code =
        "sentiment_pipeline = pipeline('sentiment-analysis')\n"
        "feedback_list = []\n"
        "try:\n"
        "    with open('/home/eya/Desktop/Parky/projectc/review.txt', 'r') as file:\n"
        "        feedback_list = [line.strip() for line in file if line.strip()]\n"
        "except Exception as e:\n"
        "    print(f'Error reading file: {e}')\n"
        "data = feedback_list\n"
        "result_list = sentiment_pipeline(data)\n"
        "result_json = json.dumps(result_list)";
    if (PyRun_SimpleString(python_setup_code) != 0) {
        fprintf(stderr, "Error executing Python sentiment analysis\n");
        return;
    }

    // Retrieve the JSON result from Python
    PyObject *pModule = PyImport_AddModule("__main__");
    PyObject *pGlobals = PyModule_GetDict(pModule);
    PyObject *pValue = PyRun_String("result_json", Py_eval_input, pGlobals, NULL);

    if (!pValue) {
        PyErr_Print();
        return;
    }

    // Convert the result to a C string
    const char *result_str = PyUnicode_AsUTF8(pValue);
    if (!result_str) {
        fprintf(stderr, "Error converting Python result to string\n");
        Py_XDECREF(pValue);
        return;
    }

    // Parse the JSON result using Jansson
    json_error_t error;
    json_t *json_result = json_loads(result_str, 0, &error);
    if (!json_result) {
        fprintf(stderr, "Error parsing JSON: %s\n", error.text);
        Py_XDECREF(pValue);
        return;
    }

    // Process the JSON result
    size_t array_size = json_array_size(json_result);
    int sentiment_array[array_size];
    for (size_t i = 0; i < array_size; i++) {
        json_t *item = json_array_get(json_result, i);
        json_t *label = json_object_get(item, "label");
        if (label && strcmp(json_string_value(label), "POSITIVE") == 0) {
            sentiment_array[i] = 1;
        } else {
            sentiment_array[i] = 0;
        }
    }

    // Calculate statistics
    int count_zeros = 0, count_ones = 0;
    for (size_t i = 0; i < array_size; i++) {
        if (sentiment_array[i] == 0) count_zeros++;
        else count_ones++;
    }
    float percentage_zeros = (count_zeros / (float)array_size) * 100;
    float percentage_ones = (count_ones / (float)array_size) * 100;
// Print statistics
    printf("Statistics:\n");
    
   printf("Count of 0s: %d\n", count_zeros);
    printf("Count of 1s: %d\n", count_ones);
    printf("Percentage of 0s: %.2f%%\n", percentage_zeros);
    printf("Percentage of 1s: %.2f%%\n", percentage_ones);
    

    // Display statistics
    char pos_text[50], neg_text[50];
    snprintf(pos_text, sizeof(pos_text), "%.2f%%  ( %d ) ", percentage_ones,count_ones);
    snprintf(neg_text, sizeof(neg_text), "%.2f%%  ( %d ) ", percentage_zeros,count_zeros);
    //gtk_label_set_text(GTK_LABEL(label_pos), pos_text);
    //gtk_label_set_text(GTK_LABEL(label_neg), neg_text);
char markup_pos_text[256];
char markup_neg_text[256];

snprintf(markup_pos_text, sizeof(markup_pos_text), "<span foreground='green'>%s</span>", pos_text);
snprintf(markup_neg_text, sizeof(markup_neg_text), "<span foreground='DARKRED'>%s</span>", neg_text);

// Appliquer le texte formaté aux labels
gtk_label_set_markup(GTK_LABEL(label_pos), markup_pos_text);
gtk_label_set_markup(GTK_LABEL(label_neg), markup_neg_text);

    // Clean up
    json_decref(json_result);
    Py_XDECREF(pValue);



}
    







//guezguez



void setup_treeview_columns(GtkTreeView *treeview) {
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;

    renderer = gtk_cell_renderer_text_new();

    column = gtk_tree_view_column_new_with_attributes("Nom Parking", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("ID Parking", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("Localisation", renderer, "text", 2, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("Capacité", renderer, "text", 3, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("Disponible", renderer, "text", 4, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("Prix", renderer, "text", 5, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("Etat", renderer, "text", 6, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text", 7, NULL);
    gtk_tree_view_append_column(treeview, column);

    // This column will now display the agent ID assigned to the parking
    column = gtk_tree_view_column_new_with_attributes("ID Agent", renderer, "text", 8, NULL);
    gtk_tree_view_append_column(treeview, column);
}



void populate_treeview(GtkTreeView *treeview, const char *filename) {
    GtkListStore *store;
    GtkTreeIter iter;
    FILE *file = fopen(filename, "r");
    char line[256];

    // Create a GtkListStore with 9 columns (8 fields + 1 for agent ID)
    store = gtk_list_store_new(9, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, 
                               G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);

    gtk_tree_view_set_model(treeview, GTK_TREE_MODEL(store));

    while (fgets(line, sizeof(line), file)) {
        Parking p;
        
        // Parse the line to fill the parking structure, including the agent ID
        sscanf(line, "%99[^;];%d;%99[^;];%d;%d;%d;%99[^;];%99[^;];%d",
               p.nompark, &p.idpark, p.localisationpark, &p.capacitepark, 
               &p.nbrdispopark, &p.prixpark, p.etatpark, p.typepark, &p.id_agents);

        // Add data to the GtkListStore (including agent ID)
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter, 0, p.nompark, 1, p.idpark, 2, p.localisationpark, 
                           3, p.capacitepark, 4, p.nbrdispopark, 5, p.prixpark, 
                           6, p.etatpark, 7, p.typepark, 8, p.id_agents, -1);
    }

    fclose(file);
}



void on_btn_aff_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *treeview = lookup_widget(GTK_WIDGET(button), "treeview1");

    // Setup and populate TreeView
    setup_treeview_columns(GTK_TREE_VIEW(treeview));
    populate_treeview(GTK_TREE_VIEW(treeview), "parking.txt");
}
















void setup_treeview3_columns(GtkTreeView *treeview) {
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;

    renderer = gtk_cell_renderer_text_new();

    // Column for ID Agent
    column = gtk_tree_view_column_new_with_attributes("ID Agent", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(treeview, column);

    // Column for Nom Agent
    column = gtk_tree_view_column_new_with_attributes("Nom Agent", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(treeview, column);
}
void populate_treeview3(GtkTreeView *treeview, const char *filename) {
    GtkListStore *store;
    GtkTreeIter iter;
    FILE *file = fopen(filename, "r");
    char line[256];

    store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING); // 2 columns: ID Agent and Nom Agent
    gtk_tree_view_set_model(treeview, GTK_TREE_MODEL(store));

    if (!file) {
        perror("Error opening agents.txt");
        return;
    }

    while (fgets(line, sizeof(line), file)) {
        Agent a;
        char nom[100], prenom[100];

        // Parse the agent details
        sscanf(line, "%d %*d %*d %99s %99s %*s %*s %*d-%*d-%*d %*s %*d %*s %*s %*s %*s %*s %*s",
               &a.idagent, nom, prenom);

        // Safely combine nom and prenom into a.nom
        snprintf(a.nom, sizeof(a.nom), "%s %s", nom, prenom);

        // Add data to the GtkListStore
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter, 0, a.idagent, 1, a.nom, -1);
    }

    fclose(file);
}


void on_btn_aff_agents_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *treeview = lookup_widget(GTK_WIDGET(button), "treeview3");

    // Setup and populate TreeView3
    setup_treeview3_columns(GTK_TREE_VIEW(treeview));
    populate_treeview3(GTK_TREE_VIEW(treeview), "agents.txt");
}




















// Function to initialize a Parking instance with default values
void init_parking(Parking *p) {
    strcpy(p->nompark, "");
    p->idpark = 0;
    strcpy(p->localisationpark, "");
    p->capacitepark = 0;
    p->nbrdispopark = 0;
    p->prixpark = 0;
    strcpy(p->etatpark, "N/A");
    strcpy(p->typepark, "N/A");
    p->id_agents = 0;
}


int ajouterp(Parking p, const char *fichier) {
    FILE *file = fopen(fichier, "a");
    if (file != NULL) {
        fprintf(file, "%s;%d;%s;%d;%d;%d;%s;%s;%d\n",
                p.nompark, p.idpark, p.localisationpark, p.capacitepark,
                p.nbrdispopark, p.prixpark, p.etatpark, p.typepark, p.id_agents);
        fclose(file);
        return 1;
    }
    return 0;
}


void on_btn_ajouterpark_clicked(GtkButton *button, gpointer user_data) {
    Parking p;
    GtkWidget *entry_nompark, *entry_idpark, *entry_localisationpark, *entry_capacitepark;
    GtkWidget *entry_nbrdispopark, *entry_prixpark, *combobox_etatpark, *combobox_typepark;
    GtkWidget *message, *id_uni_label;
    char fichier[] = "parking.txt";
    char msg[] = "Enregistrement avec succès";
    FILE *file;
    char line[256];
    int id_exists = 0;

    // Initialize the parking structure with default values
    init_parking(&p);

    // Get widgets
    entry_nompark = lookup_widget(GTK_WIDGET(button), "entry_nompark");
    entry_idpark = lookup_widget(GTK_WIDGET(button), "entry_idpark");
    entry_localisationpark = lookup_widget(GTK_WIDGET(button), "entry_localisationpark");
    entry_capacitepark = lookup_widget(GTK_WIDGET(button), "entry_capacitepark");
    entry_nbrdispopark = lookup_widget(GTK_WIDGET(button), "entry_nbrdispopark");
    entry_prixpark = lookup_widget(GTK_WIDGET(button), "entry_prixpark");
    combobox_etatpark = lookup_widget(GTK_WIDGET(button), "combobox_etatpark");
    combobox_typepark = lookup_widget(GTK_WIDGET(button), "combobox_typepark");
    message = lookup_widget(GTK_WIDGET(button), "labelmsg");
    id_uni_label = lookup_widget(GTK_WIDGET(button), "id_uni");

    // Fill parking structure
    strcpy(p.nompark, gtk_entry_get_text(GTK_ENTRY(entry_nompark)));
    p.idpark = atoi(gtk_entry_get_text(GTK_ENTRY(entry_idpark)));
    strcpy(p.localisationpark, gtk_entry_get_text(GTK_ENTRY(entry_localisationpark)));
    p.capacitepark = atoi(gtk_entry_get_text(GTK_ENTRY(entry_capacitepark)));
    p.nbrdispopark = atoi(gtk_entry_get_text(GTK_ENTRY(entry_nbrdispopark)));
    p.prixpark = atoi(gtk_entry_get_text(GTK_ENTRY(entry_prixpark)));

    if (combobox_etatpark != NULL) {
        gchar *etat = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_etatpark));
        if (etat != NULL) {
            strcpy(p.etatpark, etat);
            g_free(etat);
        }
    }

    if (combobox_typepark != NULL) {
        gchar *type = gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_typepark));
        if (type != NULL) {
            strcpy(p.typepark, type);
            g_free(type);
        }
    }

    // Check if the ID already exists in the file
    file = fopen(fichier, "r");
    if (file != NULL) {
        while (fgets(line, sizeof(line), file)) {
            Parking temp;
            sscanf(line, "%99[^;];%d;%99[^;];%d;%d;%d;%99[^;];%99[^\n]",
                   temp.nompark, &temp.idpark, temp.localisationpark, &temp.capacitepark,
                   &temp.nbrdispopark, &temp.prixpark, temp.etatpark, temp.typepark);

            if (temp.idpark == p.idpark) {
                id_exists = 1;
                break;
            }
        }
        fclose(file);
    }

    if (id_exists) {
        gtk_label_set_text(GTK_LABEL(id_uni_label), "This ID already exists");
    } else if (ajouterp(p, fichier)) {
        gtk_label_set_text(GTK_LABEL(message), msg);
        gtk_label_set_text(GTK_LABEL(id_uni_label), ""); // Clear ID error message

        // Clear the input fields after successful addition
        gtk_entry_set_text(GTK_ENTRY(entry_nompark), "");
        gtk_entry_set_text(GTK_ENTRY(entry_idpark), "");
        gtk_entry_set_text(GTK_ENTRY(entry_localisationpark), "");
        gtk_entry_set_text(GTK_ENTRY(entry_capacitepark), "");
        gtk_entry_set_text(GTK_ENTRY(entry_nbrdispopark), "");
        gtk_entry_set_text(GTK_ENTRY(entry_prixpark), "");
        gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_etatpark), -1);
        gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_typepark), -1);
    } else {
        gtk_label_set_text(GTK_LABEL(message), "Erreur lors de l'enregistrement");
    }
}

void on_btn_supp_clicked(GtkWidget *widget, gpointer data) {
    GtkWidget *treeview = lookup_widget(widget, "treeview1");
    GtkTreeSelection *selection;
    GtkTreeModel *model;
    GtkTreeIter iter;
    GtkListStore *store;
    gchar *nompark;
    int idpark;

    // Get the selected row
    selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        // Get the values from the selected row (assuming they are in columns 0 and 1)
        gtk_tree_model_get(model, &iter, 0, &nompark, 1, &idpark, -1);

        // Create a confirmation dialog
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(widget)),
                                                   GTK_DIALOG_MODAL,
                                                   GTK_MESSAGE_WARNING,
                                                   GTK_BUTTONS_YES_NO,
                                                   "Are you sure you want to delete the parking '%s' with ID %d?",
                                                   nompark, idpark);

        // Run the dialog and get the user's response
        gint response = gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);

        if (response == GTK_RESPONSE_YES) {
            // Remove the selected row from the tree view (GtkListStore)
            store = GTK_LIST_STORE(model);
            gtk_list_store_remove(store, &iter);

            // Update the parking.txt file to remove the entry
            remove_parking_from_file(nompark, idpark);
        }

        // Free allocated memory for strings retrieved from the model
        g_free(nompark);
    }
}

// Function to remove parking from the file
void remove_parking_from_file(const gchar *nompark, int idpark) {
    FILE *file = fopen("parking.txt", "r");
    FILE *temp_file = fopen("temp.txt", "w");
    char line[256];
    Parking p;

    if (file == NULL || temp_file == NULL) {
        return;
    }

    // Read the original file line by line
    while (fgets(line, sizeof(line), file)) {
        sscanf(line, "%99[^;];%d;%99[^;];%d;%d;%d;%99[^;];%99[^\n]", p.nompark, &p.idpark, p.localisationpark, &p.capacitepark, &p.nbrdispopark, &p.prixpark, p.etatpark, p.typepark);

        // Skip the line that matches the parking to delete
        if (strcmp(nompark, p.nompark) != 0 || idpark != p.idpark) {
           fprintf(temp_file, "%s;%d;%s;%d;%d;%d;%s;%s;%d\n",
        p.nompark, p.idpark, p.localisationpark, p.capacitepark, 
        p.nbrdispopark, p.prixpark, p.etatpark, p.typepark, p.id_agents);

        }
    }

    fclose(file);
    fclose(temp_file);

    // Remove the original file and rename the temp file
    remove("parking.txt");
    rename("temp.txt", "parking.txt");
}

void on_btn_search_park_clicked(GtkButton *button, gpointer user_data) {
    const char *search_term;
    GtkWidget *entry_search_park, *dialog, *label;
    FILE *file = fopen("parking.txt", "r");
    char line[256];
    Parking p;
    int found = 0; // Flag to check if we find the parking ID

    // Get the ID entered in the entry widget
    entry_search_park = lookup_widget(GTK_WIDGET(button), "entry_search_park");
    if (entry_search_park == NULL) {
        g_warning("Widget 'entry_search_park' not found.");
        return;
    }
    
    search_term = gtk_entry_get_text(GTK_ENTRY(entry_search_park));
    
    // Open the parking file for reading
    if (file == NULL) {
        g_warning("Failed to open 'parking.txt'.");
        return;
    }

    // Search for the parking information based on the entered ID
    while (fgets(line, sizeof(line), file)) {
        sscanf(line, "%99[^;];%d;%99[^;];%d;%d;%d;%99[^;];%99[^;];%d",
       p.nompark, &p.idpark, p.localisationpark, &p.capacitepark, 
       &p.nbrdispopark, &p.prixpark, p.etatpark, p.typepark, &p.id_agents);


        if (p.idpark == atoi(search_term)) {
            // Create the message dialog to show the parking info
            dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, 
                                            "Parking Found:\n\n"
                                            "Name: %s\nID: %d\nLocation: %s\nCapacity: %d\nAvailable: %d\nPrice: %d\nState: %s\nType: %s", 
                                            p.nompark, p.idpark, p.localisationpark, p.capacitepark, 
                                            p.nbrdispopark, p.prixpark, p.etatpark, p.typepark);
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
            found = 1;
            break;
        }
    }

    if (!found) {
        // Create the message dialog if parking is not found
        dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, 
                                        "Parking with ID %s not found.", search_term);
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }

    fclose(file);
}

void on_btn_modif_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *entry_search_park = lookup_widget(GTK_WIDGET(button), "entry_search_park");
    GtkWidget *entry_nompark = lookup_widget(GTK_WIDGET(button), "entry_nompark");
    GtkWidget *entry_idpark = lookup_widget(GTK_WIDGET(button), "entry_idpark");
    GtkWidget *entry_localisationpark = lookup_widget(GTK_WIDGET(button), "entry_localisationpark");
    GtkWidget *entry_capacitepark = lookup_widget(GTK_WIDGET(button), "entry_capacitepark");
    GtkWidget *entry_nbrdispopark = lookup_widget(GTK_WIDGET(button), "entry_nbrdispopark");
    GtkWidget *entry_prixpark = lookup_widget(GTK_WIDGET(button), "entry_prixpark");
    GtkWidget *notebook = lookup_widget(GTK_WIDGET(button), "notebook9");
    
    GtkWidget *combobox_etatpark = lookup_widget(GTK_WIDGET(button), "combobox_etatpark");
    GtkWidget *combobox_typepark = lookup_widget(GTK_WIDGET(button), "combobox_typepark");
    

    const char *id_search = gtk_entry_get_text(GTK_ENTRY(entry_search_park));
    FILE *file = fopen("parking.txt", "r");
    if (!file) return;

    char line[512];
    int found = 0;

    // Type options
    const char *type_options[] = {
        "Residential", "Commercial", "Covered", "Private", "Public", "Open-air", "Disabled-accessible"
    };
    
    // Etat options
    const char *etat_options[] = {
        "Open", "Closed", "Under Maintenance", "Full"
    };

    // Get the model of the combo boxes
    GtkListStore *store_etat = GTK_LIST_STORE(gtk_combo_box_get_model(GTK_COMBO_BOX(combobox_etatpark)));
    GtkListStore *store_type = GTK_LIST_STORE(gtk_combo_box_get_model(GTK_COMBO_BOX(combobox_typepark)));

    // Clear the model (removes all items)
    gtk_list_store_clear(store_etat);
    gtk_list_store_clear(store_type);

    for (int i = 0; i < 4; i++) {
        GtkTreeIter iter;
        gtk_list_store_append(store_etat, &iter);
        gtk_list_store_set(store_etat, &iter, 0, etat_options[i], -1);
    }

    // Populate ComboBoxes with the options
    for (int i = 0; i < 7; i++) {
        GtkTreeIter iter;
        gtk_list_store_append(store_type, &iter);
        gtk_list_store_set(store_type, &iter, 0, type_options[i], -1);
    }

    // Read file and find parking
    while (fgets(line, sizeof(line), file)) {
        char nom[100], id[10], localisation[100], capacite[10], dispo[10], prix[10], type[50], etat[50];
        sscanf(line, "%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^\n]",
               nom, id, localisation, capacite, dispo, prix, type, etat);

        if (strcmp(id, id_search) == 0) {
            gtk_entry_set_text(GTK_ENTRY(entry_nompark), nom);
            gtk_entry_set_text(GTK_ENTRY(entry_idpark), id);
            gtk_entry_set_text(GTK_ENTRY(entry_localisationpark), localisation);
            gtk_entry_set_text(GTK_ENTRY(entry_capacitepark), capacite);
            gtk_entry_set_text(GTK_ENTRY(entry_nbrdispopark), dispo);
            gtk_entry_set_text(GTK_ENTRY(entry_prixpark), prix);

            // Set the ComboBox selection for 'etat'
            for (int i = 0; i < 4; i++) {
                if (strcmp(etat, etat_options[i]) == 0) {
                    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_etatpark), i);
                    break;
                }
            }
            // Set the ComboBox selection for 'type'
            for (int i = 0; i < 7; i++) {
                if (strcmp(type, type_options[i]) == 0) {
                    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_typepark), i);
                    break;
                }
            }

            found = 1;
            break;
        }
    }

    fclose(file);

    if (!found) {
        // Optionally, display a message to indicate no matching parking was found.
    }

    // Navigate to the first tab of notebook1
    if (notebook != NULL) {
        gtk_notebook_set_current_page(GTK_NOTEBOOK(notebook), 0);
    }
}



// Comparison function for sorting by idpark

// Comparison function for sorting by capacitepark (descending order)
int compare_parking_by_capacity_desc(const void *a, const void *b) {
   return ((Parking *)b)->capacitepark - ((Parking *)a)->capacitepark;
}


/*void on_btn_sort_by_capacite_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    FILE *file = fopen("parking.txt", "r");
    if (!file) {
        perror("Error opening parking.txt");
        return;
    }

    // Step 1: Read the file into an array of Parking structures
    Parking parkings[100]; // Assuming a max of 100 entries
    int count = 0;
    while (fscanf(file, "%99[^;];%d;%99[^;];%d;%d;%d;%49[^;];%49[^;];%d\n",
                  parkings[count].nompark, &parkings[count].idpark, parkings[count].localisationpark,
                  &parkings[count].capacitepark, &parkings[count].nbrdispopark, &parkings[count].prixpark,
                  parkings[count].typepark, parkings[count].etatpark, &parkings[count].id_agents) != EOF) {
        count++;
    }
    fclose(file);

    // Step 2: Sort the array by capacitepark in descending order
    qsort(parkings, count, sizeof(Parking), compare_parking_by_capacity_desc);

    // Step 3: Write the sorted data back to parking.txt
    file = fopen("parking.txt", "w");
    if (!file) {
        perror("Error writing to parking.txt");
        return;
    }
    for (int i = 0; i < count; i++) {
        fprintf(file, "%s;%d;%s;%d;%d;%d;%s;%s;%d\n",
                parkings[i].nompark, parkings[i].idpark, parkings[i].localisationpark,
                parkings[i].capacitepark, parkings[i].nbrdispopark, parkings[i].prixpark,
                parkings[i].typepark, parkings[i].etatpark, parkings[i].id_agents);
    }
    fclose(file);

    printf("parking.txt has been sorted by capacity (descending order).\n");
}*/


void on_btn_save_modif_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *entry_search_park = lookup_widget(GTK_WIDGET(button), "entry_search_park");
    GtkWidget *entry_nompark = lookup_widget(GTK_WIDGET(button), "entry_nompark");
    GtkWidget *entry_idpark = lookup_widget(GTK_WIDGET(button), "entry_idpark");
    GtkWidget *entry_localisationpark = lookup_widget(GTK_WIDGET(button), "entry_localisationpark");
    GtkWidget *entry_capacitepark = lookup_widget(GTK_WIDGET(button), "entry_capacitepark");
    GtkWidget *entry_nbrdispopark = lookup_widget(GTK_WIDGET(button), "entry_nbrdispopark");
    GtkWidget *entry_prixpark = lookup_widget(GTK_WIDGET(button), "entry_prixpark");
    GtkWidget *combobox_typepark = lookup_widget(GTK_WIDGET(button), "combobox_typepark");
    GtkWidget *combobox_etatpark = lookup_widget(GTK_WIDGET(button), "combobox_etatpark");

    const char *id_search = gtk_entry_get_text(GTK_ENTRY(entry_search_park));
    const char *new_nom = gtk_entry_get_text(GTK_ENTRY(entry_nompark));
    const char *new_id = gtk_entry_get_text(GTK_ENTRY(entry_idpark));
    const char *new_localisation = gtk_entry_get_text(GTK_ENTRY(entry_localisationpark));
    const char *new_capacite = gtk_entry_get_text(GTK_ENTRY(entry_capacitepark));
    const char *new_dispo = gtk_entry_get_text(GTK_ENTRY(entry_nbrdispopark));
    const char *new_prix = gtk_entry_get_text(GTK_ENTRY(entry_prixpark));

    GtkComboBox *combo_box_type = GTK_COMBO_BOX(combobox_typepark);
    GtkComboBox *combo_box_etat = GTK_COMBO_BOX(combobox_etatpark);

    // Get the active index of the combo boxes
    gint active_type = gtk_combo_box_get_active(combo_box_type);
    gint active_etat = gtk_combo_box_get_active(combo_box_etat);

    // If the combo box has valid items, retrieve the active text
    const char *new_type = (active_type != -1) ? gtk_combo_box_get_active_text(combo_box_type) : NULL;
    const char *new_etat = (active_etat != -1) ? gtk_combo_box_get_active_text(combo_box_etat) : NULL;

    FILE *file = fopen("parking.txt", "r");
    FILE *temp = fopen("temp.txt", "w");
    if (!file || !temp) return;

    char line[512];
    int found = 0;

    while (fgets(line, sizeof(line), file)) {
        char nom[100], id[10], localisation[100], capacite[10], dispo[10], prix[10], type[50], etat[50];
        sscanf(line, "%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^;];%[^\n]",
               nom, id, localisation, capacite, dispo, prix, type, etat);

        if (strcmp(id, id_search) == 0) {
            fprintf(temp, "%s;%s;%s;%s;%s;%s;%s;%s\n",
                    new_nom, new_id, new_localisation, new_capacite, new_dispo, new_prix, new_type, new_etat);
            found = 1;
        } else {
            fprintf(temp, "%s", line);
        }
    }

    fclose(file);
    fclose(temp);

    if (found) {
        remove("parking.txt");
        rename("temp.txt", "parking.txt");
    } else {
        remove("temp.txt");
        // Optionally, notify the user that no matching parking was found.
    }

    // Clear the input fields after successful modification
    gtk_entry_set_text(GTK_ENTRY(entry_nompark), "");
    gtk_entry_set_text(GTK_ENTRY(entry_idpark), "");
    gtk_entry_set_text(GTK_ENTRY(entry_localisationpark), "");
    gtk_entry_set_text(GTK_ENTRY(entry_capacitepark), "");
    gtk_entry_set_text(GTK_ENTRY(entry_nbrdispopark), "");
    gtk_entry_set_text(GTK_ENTRY(entry_prixpark), "");
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_etatpark), -1);
    gtk_combo_box_set_active(GTK_COMBO_BOX(combobox_typepark), -1);
}


void on_button_assign_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *entry_idagent = lookup_widget(GTK_WIDGET(button), "entry_idagent");
    GtkWidget *entry_asignpark = lookup_widget(GTK_WIDGET(button), "entry_asignpark");

    const gchar *idagent_str = gtk_entry_get_text(GTK_ENTRY(entry_idagent));
    const gchar *asignpark_str = gtk_entry_get_text(GTK_ENTRY(entry_asignpark));

    int idagent = atoi(idagent_str);
    int asignpark = atoi(asignpark_str);

    // Open parking.txt file to find and update parking data
    FILE *parking_file = fopen("parking.txt", "r+");
    if (parking_file == NULL) {
        printf("Error opening parking file\n");
        return;
    }

    FILE *temp_parking_file = fopen("temp_parking.txt", "w");
    if (temp_parking_file == NULL) {
        printf("Error opening temporary parking file\n");
        fclose(parking_file);
        return;
    }

    char line[256];
    Parking p;
    int agent_found = 0;

    // Loop through parking.txt to find the parking and update the assigned agent
    while (fgets(line, sizeof(line), parking_file)) {
        sscanf(line, "%99[^;];%d;%99[^;];%d;%d;%d;%99[^;];%99[^;];%d", 
               p.nompark, &p.idpark, p.localisationpark, &p.capacitepark, 
               &p.nbrdispopark, &p.prixpark, p.etatpark, p.typepark, &p.id_agents);

        if (p.idpark == asignpark) {
            p.id_agents = idagent;  // Assign the agent to the parking
            agent_found = 1;
        }

        // Write the updated parking data to the temporary file
        fprintf(temp_parking_file, "%s;%d;%s;%d;%d;%d;%s;%s;%d\n", 
                p.nompark, p.idpark, p.localisationpark, p.capacitepark, 
                p.nbrdispopark, p.prixpark, p.etatpark, p.typepark, p.id_agents);
    }

    fclose(parking_file);
    fclose(temp_parking_file);

    // If the agent was found and assigned, replace the old parking file
    if (agent_found) {
        rename("temp_parking.txt", "parking.txt");
        printf("Agent assigned successfully.\n");

        // Now open agents.txt to update the agent's status from 'unassigned' to 'assigned'
        FILE *agents_file = fopen("agents.txt", "r+");
        if (agents_file == NULL) {
            printf("Error opening agents file\n");
            return;
        }

        FILE *temp_agents_file = fopen("temp_agents.txt", "w");
        if (temp_agents_file == NULL) {
            printf("Error opening temporary agents file\n");
            fclose(agents_file);
            return;
        }

        Agent agent;
        // Loop through agents.txt to find the agent and update the status and parking ID
        while (fgets(line, sizeof(line), agents_file)) {
            sscanf(line, "%d %d %d %s %s %s %s %d-%d-%d %s %d %s %s %s %s", 
                   &agent.idagent, &agent.idparking, &agent.cin, agent.nom, agent.prenom, 
                   agent.adresse, agent.role, &agent.jour, &agent.mois, &agent.annee, 
                   agent.sexe, &agent.tel, agent.exp, agent.statut, agent.email, 
                   agent.image);

            // If the agent's ID matches the one being assigned, update their status and parking ID
            if (agent.idagent == idagent) {
                strcpy(agent.statut, "assigned");
                agent.idparking = asignpark;  // Update parking ID in agent
            }

            // Write the updated agent data to the temporary file
            fprintf(temp_agents_file, "%d %d %d %s %s %s %s %d-%d-%d %s %d %s %s %s %s\n",
                    agent.idagent, agent.idparking, agent.cin, agent.nom, agent.prenom, 
                    agent.adresse, agent.role, agent.jour, agent.mois, agent.annee, 
                    agent.sexe, agent.tel, agent.exp, agent.statut, agent.email, 
                    agent.image);
        }

        fclose(agents_file);
        fclose(temp_agents_file);

        // Replace the old agents file with the updated one
        rename("temp_agents.txt", "agents.txt");
    } else {
        printf("Parking ID not found.\n");
        remove("temp_parking.txt");  // Clean up if no assignment was made
    }
}

void setup_treeview2_columns(GtkTreeView *treeview) {
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;

    // Create the cell renderer for text
    renderer = gtk_cell_renderer_text_new();

    // Setup columns similar to treeview1
    column = gtk_tree_view_column_new_with_attributes("Nom Parking", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("ID Parking", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("ID Agent 1", renderer, "text", 2, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("ID Agent 2", renderer, "text", 3, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("ID Agent 3", renderer, "text", 4, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("ID Agent 4", renderer, "text", 5, NULL);
    gtk_tree_view_append_column(treeview, column);

    column = gtk_tree_view_column_new_with_attributes("ID Agent 5", renderer, "text", 6, NULL);
    gtk_tree_view_append_column(treeview, column);
}

void populate_treeview2(GtkTreeView *treeview, const char *filename) {
    GtkListStore *store;
    GtkTreeIter iter;
    FILE *file = fopen(filename, "r");
    char line[256];
    int idparking;
    char nom_parking[50];
    char agent1[50], agent2[50], agent3[50], agent4[50], agent5[50];

    // Create a GtkListStore with 7 columns
    store = gtk_list_store_new(7, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, 
                               G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

    // Set the model for the treeview
    gtk_tree_view_set_model(treeview, GTK_TREE_MODEL(store));

    // Read data from shift.txt
    while (fgets(line, sizeof(line), file)) {
        // Parse the line
        sscanf(line, "%d;%49[^;];%49[^;];%49[^;];%49[^;];%49[^;];%49[^;\n]", 
               &idparking, nom_parking, agent1, agent2, agent3, agent4, agent5);

        // Append data to the store
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
            0, nom_parking,          // Nom Parking
            1, g_strdup_printf("%d", idparking),  // ID Parking
            2, strlen(agent1) > 0 ? agent1 : "N/A", // Agent 1
            3, strlen(agent2) > 0 ? agent2 : "N/A", // Agent 2
            4, strlen(agent3) > 0 ? agent3 : "N/A", // Agent 3
            5, strlen(agent4) > 0 ? agent4 : "N/A", // Agent 4
            6, strlen(agent5) > 0 ? agent5 : "N/A", // Agent 5
            -1);  // End of row data
    }

    fclose(file);
}

void populate_shift_txt_from_parking_and_agents() {
    FILE *parking_file = fopen("parking.txt", "r");
    if (parking_file == NULL) {
        printf("Error opening parking file\n");
        return;
    }

    FILE *agents_file = fopen("agents.txt", "r");
    if (agents_file == NULL) {
        printf("Error opening agents file\n");
        fclose(parking_file);
        return;
    }

    FILE *shift_file = fopen("shift.txt", "w");
    if (shift_file == NULL) {
        printf("Error opening shift file\n");
        fclose(parking_file);
        fclose(agents_file);
        return;
    }

    char line[256];
    Parking parking;
    Agent agent;
    int agent_count;
    char agent_ids[5][50];  // To store the agent IDs for this parking, up to 5 agents

    // Loop through the parking.txt to process each parking
    while (fgets(line, sizeof(line), parking_file)) {
        sscanf(line, "%99[^;];%d;%99[^;];%d;%d;%d;%99[^;];%99[^;];%d", 
               parking.nompark, &parking.idpark, parking.localisationpark, &parking.capacitepark, 
               &parking.nbrdispopark, &parking.prixpark, parking.etatpark, parking.typepark, &parking.id_agents);

        // Reset agent IDs
        memset(agent_ids, 0, sizeof(agent_ids));
        agent_count = 0;

        // Now check for agents associated with this parking in agents.txt
        rewind(agents_file);
        while (fgets(line, sizeof(line), agents_file)) {
            sscanf(line, "%d %d %d %s %s %s %s %d-%d-%d %s %d %s %s %s %s", 
                   &agent.idagent, &agent.idparking, &agent.cin, agent.nom, agent.prenom, 
                   agent.adresse, agent.role, &agent.jour, &agent.mois, &agent.annee, 
                   agent.sexe, &agent.tel, agent.exp, agent.statut, agent.email, 
                   agent.image);

            // If the agent is assigned to the current parking, store their ID
            if (agent.idparking == parking.idpark && agent_count < 5) {
                sprintf(agent_ids[agent_count], "%d", agent.idagent);
                agent_count++;
            }
        }

        // Write parking and agent data into shift.txt
        fprintf(shift_file, "%d;%s;", parking.idpark, parking.nompark);
        for (int i = 0; i < 5; i++) {
            if (strlen(agent_ids[i]) > 0) {
                fprintf(shift_file, "%s;", agent_ids[i]);  // Write agent ID
            } else {
                fprintf(shift_file, "N/A;");  // If no agent assigned, write "N/A"
            }
        }
        fprintf(shift_file, "\n");
    }

    fclose(parking_file);
    fclose(agents_file);
    fclose(shift_file);

    printf("shift.txt updated successfully.\n");
}


void on_btn_refreshagent_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *treeview2 = lookup_widget(GTK_WIDGET(button), "treeview2");

    // Setup treeview2 columns
    setup_treeview2_columns(GTK_TREE_VIEW(treeview2));

    // Populate treeview2 with updated data from shift.txt
    populate_shift_txt_from_parking_and_agents();  // Ensure shift.txt is updated
    populate_treeview2(GTK_TREE_VIEW(treeview2), "shift.txt");
}

int compare_parking_by_id(const void *a, const void *b) {
    return ((Parking *)a)->idpark - ((Parking *)b)->idpark;
}

int compare_parking_by_nom(const void *a, const void *b) {
    return strcmp(((Parking *)a)->nompark, ((Parking *)b)->nompark);
}

int compare_parking_by_capacite(const void *a, const void *b) {
    return ((Parking *)b)->capacitepark - ((Parking *)a)->capacitepark;
}

int compare_parking_by_prix(const void *a, const void *b) {
    return ((Parking *)a)->prixpark - ((Parking *)b)->prixpark;
}

// Function to read parking data from file
int load_parking_data(Parking *parkings, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening parking.txt");
        return 0;
    }
    int count = 0;
    while (fscanf(file, "%99[^;];%d;%99[^;];%d;%d;%d;%49[^;];%49[^;];%d\n",
                  parkings[count].nompark, &parkings[count].idpark, parkings[count].localisationpark,
                  &parkings[count].capacitepark, &parkings[count].nbrdispopark, &parkings[count].prixpark,
                  parkings[count].typepark, parkings[count].etatpark, &parkings[count].id_agents) != EOF) {
        count++;
    }
    fclose(file);
    return count;
}

// Function to write parking data back to file
void save_parking_data(Parking *parkings, int count, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Error writing to parking.txt");
        return;
    }
    for (int i = 0; i < count; i++) {
        fprintf(file, "%s;%d;%s;%d;%d;%d;%s;%s;%d\n",
                parkings[i].nompark, parkings[i].idpark, parkings[i].localisationpark,
                parkings[i].capacitepark, parkings[i].nbrdispopark, parkings[i].prixpark,
                parkings[i].typepark, parkings[i].etatpark, parkings[i].id_agents);
    }
    fclose(file);
}

// Generalized sort function
void sort_parking_data(GtkToggleButton *togglebutton, int (*compare_func)(const void *, const void *)) {
    if (!gtk_toggle_button_get_active(togglebutton)) {
        return;
    }

    Parking parkings[100];
    int count = load_parking_data(parkings, "parking.txt");
    if (count > 0) {
        qsort(parkings, count, sizeof(Parking), compare_func);
        save_parking_data(parkings, count, "parking.txt");
    }
}

// Sorting callbacks
void on_btn_sort_by_id_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    sort_parking_data(togglebutton, compare_parking_by_id);
}

void on_btn_sort_by_nom_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    sort_parking_data(togglebutton, compare_parking_by_nom);
}
void on_btn_sort_by_prix_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    sort_parking_data(togglebutton, compare_parking_by_prix);
}

void on_btn_sort_by_capacite_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    sort_parking_data(togglebutton, compare_parking_by_capacite);
}







static gdouble current_progress = 0.0;  // Global variable to track the current progress
static gdouble target_progress = 0.0;   // Global variable to track the target progress

// This function will incrementally update the progress bar towards the target value
gboolean update_progress(gpointer progress_bar) {
    if (current_progress < target_progress) {
        current_progress += 0.005;  // Increment progress by 1% per call (adjust this rate)
        gtk_progress_bar_set_fraction(GTK_PROGRESS_BAR(progress_bar), current_progress);
        return TRUE;  // Continue the timeout function
    }
    return FALSE;  // Stop the timeout function once the progress reaches the target
}

void on_btn_visual_clicked(GtkButton *button, gpointer user_data) {
    GtkProgressBar *progress_bar = GTK_PROGRESS_BAR(lookup_widget(GTK_WIDGET(button), "progress_parking_availability"));
    GtkEntry *entry_search_park = GTK_ENTRY(lookup_widget(GTK_WIDGET(button), "entry_search_park"));
    const char *search_input = gtk_entry_get_text(entry_search_park);  // Get ID from the entry

    FILE *file = fopen("parking.txt", "r");
    if (!file) {
        printf("Error opening parking.txt\n");
        return;
    }

    char line[MAX_LINE_LENGTH];
    Parking parking_data;
    gboolean found = FALSE;

    // Search for the parking by ID in the file
    while (fgets(line, sizeof(line), file)) {
        char *token = strtok(line, ";");

        // Read each token and populate the parking_data structure
        int field_index = 0;
        while (token != NULL) {
            switch (field_index) {
                case 0:
                    strncpy(parking_data.nompark, token, sizeof(parking_data.nompark));
                    break;
                case 1:
                    parking_data.idpark = atoi(token);
                    break;
                case 2:
                    strncpy(parking_data.localisationpark, token, sizeof(parking_data.localisationpark));
                    break;
                case 3:
                    parking_data.capacitepark = atoi(token);
                    break;
                case 4:
                    parking_data.nbrdispopark = atoi(token);
                    break;
                case 5:
                    parking_data.prixpark = atoi(token);
                    break;
                case 6:
                    strncpy(parking_data.typepark, token, sizeof(parking_data.typepark));
                    break;
                case 7:
                    strncpy(parking_data.etatpark, token, sizeof(parking_data.etatpark));
                    break;
                case 8:
                    parking_data.id_agents = atoi(token);
                    break;
            }
            token = strtok(NULL, ";");
            field_index++;
        }

        // Check if the parking ID matches the search input
        if (parking_data.idpark == atoi(search_input)) {
            found = TRUE;
            break;
        }
    }

    fclose(file);

    if (!found) {
        printf("Parking ID not found.\n");
        return;
    }

    // Ensure capacitepark and nbrdispopark are valid before calculating
    if (parking_data.capacitepark == 0 || parking_data.nbrdispopark == 0) {
        printf("Invalid capacite or disponible values: capacite = %d, disponible = %d\n", parking_data.capacitepark, parking_data.nbrdispopark);
        return;
    }

    // Calculate the percentage of available space
    gdouble percentage = ((double) parking_data.nbrdispopark / parking_data.capacitepark) * 100.0;

    // Ensure percentage is within valid range (0 to 100)
    if (percentage < 0) percentage = 0;
    if (percentage > 100) percentage = 100;

    // Set the target progress value based on the calculated percentage
    target_progress = percentage / 100.0;

    // Initialize the current progress and start the loading animation
    current_progress = 0.0;

    // Set the progress bar to start the animation
    g_timeout_add(20, update_progress, progress_bar);  // Update every 20ms for smooth progress

    // Optionally update the progress bar text (optional)
    gchar *progress_text = g_strdup_printf("%.2f%% Available", percentage);
    gtk_progress_bar_set_text(progress_bar, progress_text);
    g_free(progress_text);
}



//mo3taz


int t; // Service type (1 for Normal, 2 for VIP)
char filepath[] = "/home/eya/Desktop/Parky/projectc/Serv.txt";

// Adding a new service
void initialize_combobox(GtkWidget *combobox) {
    GtkListStore *store;
    GtkTreeIter iter;

    // Create a new list store with one column of type string
    store = gtk_list_store_new(1, G_TYPE_STRING);

    // Append the options to the store
    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "5%", -1);

    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "10%", -1);

    gtk_list_store_append(store, &iter);
    gtk_list_store_set(store, &iter, 0, "15%", -1);

    // Set the model for the combobox
    gtk_combo_box_set_model(GTK_COMBO_BOX(combobox), GTK_TREE_MODEL(store));

    // Free the reference to the store (combobox holds its own reference)
    g_object_unref(store);
}
// Initialize TreeView with Columns
void initialize_treeview(GtkWidget *treeview) {
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkListStore *store;

    // Create a ListStore with 5 columns
    store = gtk_list_store_new(5, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

    // ID Service Column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("ID Service", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    // Description Column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Description", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    // Prix Column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Prix", renderer, "text", 2, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    // Type Service Column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Type Service", renderer, "text", 3, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    // Offre Column
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Offre", renderer, "text", 4, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    // Attach the ListStore to the TreeView
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
}

// Update TreeView with Data from File
void update_treeview(GtkWidget *treeview) {
    GtkListStore *store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(treeview)));
    GtkTreeIter iter;

    // Clear the store
    gtk_list_store_clear(store);

    // Open the file and populate the TreeView
    FILE *file = fopen(filepath, "r");
    if (!file) {
        g_print("Error opening file: %s\n", filepath);
        return;
    }

    Serv s;
    while (fscanf(file, "%d %99s %9s %9s %9s", 
                  &s.ID_service, s.description, s.Prix, s.type_service, s.offre) != EOF) {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, s.ID_service,
                           1, s.description,
                           2, s.Prix,
                           3, s.type_service,
                           4, s.offre, -1);
    }
    fclose(file);
}

// Add New Service
void on_button4_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *entry_id, *entry_description, *entry_prix, *radio_normal, *radio_vip, *combobox, *treeview;

    entry_id = lookup_widget(GTK_WIDGET(button), "entry1");
    entry_description = lookup_widget(GTK_WIDGET(button), "entry2");
    entry_prix = lookup_widget(GTK_WIDGET(button), "entry3");
    radio_normal = lookup_widget(GTK_WIDGET(button), "radiobutton1");
    radio_vip = lookup_widget(GTK_WIDGET(button), "radiobutton2");
    combobox = lookup_widget(GTK_WIDGET(button), "combobox");
    treeview = lookup_widget(GTK_WIDGET(button), "treeviewserv");

    Serv s;
    s.ID_service = atoi(gtk_entry_get_text(GTK_ENTRY(entry_id)));
    strcpy(s.description, gtk_entry_get_text(GTK_ENTRY(entry_description)));
    strcpy(s.Prix, gtk_entry_get_text(GTK_ENTRY(entry_prix)));

    int prix_value = atoi(s.Prix); // Convert Prix to integer for comparison

    // Set offre based on Prix value
    if (prix_value >= 50 && prix_value <= 70) {
        strcpy(s.offre, "5%");
    } else if (prix_value >= 70 && prix_value < 100) {
        strcpy(s.offre, "10%");
    } else if (prix_value >= 100) {
        strcpy(s.offre, "15%");
    } else {
        strcpy(s.offre, "N/A"); // Default for prices below 50
    }

    // Check the service type (NORMAL or VIP)
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_normal))) {
        strcpy(s.type_service, "NORMAL");
        strcpy(s.offre, "N/A"); // Normal services do not have an offer
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_vip))) {
        strcpy(s.type_service, "VIP");
    }

    // Check if the ID exists in the file
    FILE *file = fopen(filepath, "r");
    FILE *temp_file = fopen("Serv.txt", "a");

    if (!file || !temp_file) {
        g_print("Error opening file\n");
        return;
    }

    Serv temp;
    int id_exists = 0;

    // Copy data to a temporary file, updating the entry if ID matches
    while (fscanf(file, "%d %99s %9s %9s %9s", 
                  &temp.ID_service, temp.description, temp.Prix, temp.type_service, temp.offre) != EOF) {
        if (temp.ID_service == s.ID_service) {
            // Update the existing record
            fprintf(temp_file, "%d %s %s %s %s\n", s.ID_service, s.description, s.Prix, s.type_service, s.offre);
            id_exists = 1;
        } else {
            // Copy the existing record as-is
            fprintf(temp_file, "%d %s %s %s %s\n", temp.ID_service, temp.description, temp.Prix, temp.type_service, temp.offre);
        }
    }

    fclose(file);
    fclose(temp_file);

    // Replace the original file with the updated file
    remove(filepath);
    rename("Serv.txt", filepath);

    // If the ID did not exist, append it to the file
    if (!id_exists) {
        file = fopen(filepath, "a");
        if (file) {
            fprintf(file, "%d %s %s %s %s\n", s.ID_service, s.description, s.Prix, s.type_service, s.offre);
            fclose(file);
        }
    }

    // Update the TreeView to reflect the changes
    update_treeview(treeview);

    if (id_exists) {
        g_print("Service with ID %d updated successfully.\n", s.ID_service);
    } else {
        g_print("New service with ID %d added successfully.\n", s.ID_service);
    }
}

void on_button3_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *treeview, *entry_id, *entry_description, *entry_prix, *radio_normal, *radio_vip, *combobox;
    GtkTreeSelection *selection;
    GtkTreeIter iter;
    GtkTreeModel *model;

    int id;
    gchar *description, *prix, *type_service, *offre;

    // Link UI Widgets
    treeview = lookup_widget(GTK_WIDGET(button), "treeviewserv");
    entry_id = lookup_widget(GTK_WIDGET(button), "entry1");
    entry_description = lookup_widget(GTK_WIDGET(button), "entry2");
    entry_prix = lookup_widget(GTK_WIDGET(button), "entry3");
    radio_normal = lookup_widget(GTK_WIDGET(button), "radiobutton1");
    radio_vip = lookup_widget(GTK_WIDGET(button), "radiobutton2");
    combobox = lookup_widget(GTK_WIDGET(button), "combobox");

    // Get selected row
    selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        // Retrieve data from the selected row
        gtk_tree_model_get(model, &iter, 
                           0, &id, 
                           1, &description, 
                           2, &prix, 
                           3, &type_service, 
                           4, &offre, 
                           -1);

        // Populate the UI fields with the retrieved data
        char id_str[10];
        sprintf(id_str, "%d", id);
        gtk_entry_set_text(GTK_ENTRY(entry_id), id_str);
        gtk_entry_set_text(GTK_ENTRY(entry_description), description);
        gtk_entry_set_text(GTK_ENTRY(entry_prix), prix);

        // Set radio button based on type_service
        if (strcmp(type_service, "NORMAL") == 0) {
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio_normal), TRUE);
        } else if (strcmp(type_service, "VIP") == 0) {
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio_vip), TRUE);

            // Set combobox value for "offre" (VIP only)
            GtkTreeModel *combobox_model = gtk_combo_box_get_model(GTK_COMBO_BOX(combobox));
            GtkTreeIter combobox_iter;

            if (gtk_tree_model_get_iter_first(combobox_model, &combobox_iter)) {
                do {
                    gchar *combo_value;
                    gtk_tree_model_get(combobox_model, &combobox_iter, 0, &combo_value, -1);
                    if (strcmp(combo_value, offre) == 0) {
                        gtk_combo_box_set_active_iter(GTK_COMBO_BOX(combobox), &combobox_iter);
                        g_free(combo_value);
                        break;
                    }
                    g_free(combo_value);
                } while (gtk_tree_model_iter_next(combobox_model, &combobox_iter));
            }
        }

        // Free allocated memory
        g_free(description);
        g_free(prix);
        g_free(type_service);
        g_free(offre);
    } else {
        g_print("No row selected. Please select a service to modify.\n");
    }
}

// Deleting a service
void on_button10_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *treeview;

    // Link the TreeView widget
    treeview = lookup_widget(GTK_WIDGET(button), "treeviewserv");

    // Get selected row
    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
    GtkTreeIter iter;
    GtkTreeModel *model;

    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        int id;

        // Retrieve the ID of the selected row (column 0)
        gtk_tree_model_get(model, &iter, 0, &id, -1);

        // Delete the service from the file
       // supprimers(id);

        // Refresh the TreeView to reflect the changes
        update_treeview(treeview);

        g_print("Service with ID %d deleted successfully.\n", id);
    } else {
        g_print("No row selected. Please select a service to delete.\n");
    }
}

// Quit application
void on_button1_clicked(GtkButton *button, gpointer user_data) {
    gtk_main_quit();
}


char type_service[50];

// Callback: Radio button for "NORMAL" service type
void on_radiobutton1_toggled(GtkToggleButton *NORMAL, gpointer user_data) {
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(NORMAL))) {
        strcpy(type_service, "NORMAL");
    }
}

// Callback: Radio button for "VIP" service type
void on_radiobutton2_toggled(GtkToggleButton *VIP, gpointer user_data) {
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(VIP))) {
        strcpy(type_service, "VIP");
    }
}
// Refresh TreeView
/*void on_button11_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *treeview = GTK_WIDGET(user_data);
    update_treeview(treeview);
    g_print("TreeView refreshed successfully.\n");
}
*/

// Setup Initial Signals
void setup_signals(GtkWidget *parent_window) {
    GtkWidget *button11 = lookup_widget(GTK_WIDGET(parent_window), "button11");
    GtkWidget *treeview1 = lookup_widget(GTK_WIDGET(parent_window), "treeviewserv");

    initialize_treeview(treeview1);
    update_treeview(treeview1);

    g_signal_connect(button11, "clicked", G_CALLBACK(on_button11_clicked), treeview1);
}




void
on_treeviewserv_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
// You can implement the behavior for row activation here
    g_print("TreeView row activated!\n");
}
void on_button5_clicked(GtkButton *button, gpointer user_data){
    gtk_main_quit();
}


//citoyen





extern GtkBuilder *builder;



void
on_cancel_btn_edit_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_apply_btn_edit_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
    const char *filename = "citizen_profile.txt"; 
    citizen current_citizen;

    // Read the current citizen profile
    if (read_citizen_profile(filename, &current_citizen) != 0) {
        g_print("Error reading citizen profile.\n");
        return;
    }

    GtkWidget *parent_window = GTK_WIDGET(gtk_widget_get_toplevel(GTK_WIDGET(button)));
    GtkWidget *entry_name;
	GtkWidget *entry_surname;
	GtkWidget *entry_email;
	GtkWidget *entry_password;
	GtkWidget *entry_car_brand;
	GtkWidget *entry_car_serial;
	GtkWidget *entry_color;  
        GtkWidget *radio_male;  
        GtkWidget *radio_female;
        GtkWidget *file_selector;

	entry_name = lookup_widget(parent_window, "edit_name");
	entry_surname = lookup_widget(parent_window, "edit_surname");
	entry_email = lookup_widget(parent_window, "edit_email");
	entry_password = lookup_widget(parent_window, "edit_passwd");
	entry_car_brand = lookup_widget(parent_window, "edit_carbrand");
	entry_car_serial = lookup_widget(parent_window, "edit_serial");
	entry_color = lookup_widget(parent_window, "edit_color");
        radio_male = lookup_widget(parent_window, "radiomale");
        radio_female = lookup_widget(parent_window, "radiofemale");
        file_selector = lookup_widget(parent_window, "filechooserpdp");

    // Ensure all widgets are found
    if (!entry_name || !entry_surname || !entry_email || !entry_password ||
        !entry_car_brand || !entry_car_serial || !entry_color || 
        !radio_male || !radio_female || !file_selector) {
        g_print("Error: Some widgets not found!\n");
        return;
    }
    // Get the profile picture file path from the file selector (if available)
    const gchar *pdp_filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(file_selector));

    // Get updated values from user input
    const gchar *name = gtk_entry_get_text(GTK_ENTRY(entry_name));
    const gchar *surname = gtk_entry_get_text(GTK_ENTRY(entry_surname));
    const gchar *email = gtk_entry_get_text(GTK_ENTRY(entry_email));
    const gchar *password = gtk_entry_get_text(GTK_ENTRY(entry_password));
    const gchar *carbrand = gtk_entry_get_text(GTK_ENTRY(entry_car_brand));
    const gchar *serial = gtk_entry_get_text(GTK_ENTRY(entry_car_serial));
    const gchar *color = gtk_entry_get_text(GTK_ENTRY(entry_color));
    
    // Get gender from radio buttons
    const gchar *gender = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_male)) ? 
                          "Male" : 
                          (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_female)) ? "Female" : "");

    if (strlen(gender) == 0) {
        g_print("Error: Gender not selected.\n");
        return;
    }

    // Update citizen struct with new values
    strncpy(current_citizen.name, name, sizeof(current_citizen.name) - 1);
    strncpy(current_citizen.surname, surname, sizeof(current_citizen.surname) - 1);
    strncpy(current_citizen.email, email, sizeof(current_citizen.email) - 1);
    strncpy(current_citizen.password, password, sizeof(current_citizen.password) - 1);
    strncpy(current_citizen.car_brand, carbrand, sizeof(current_citizen.car_brand) - 1);
    strncpy(current_citizen.car_serial, serial, sizeof(current_citizen.car_serial) - 1);
    strncpy(current_citizen.color, color, sizeof(current_citizen.color) - 1);
    strncpy(current_citizen.gender, gender, sizeof(current_citizen.gender) - 1);
 if (pdp_filename != NULL) {
        strncpy(current_citizen.profile_picture, pdp_filename, sizeof(current_citizen.profile_picture) - 1);
    }
    // Save updated profile back to the file
    if (update_citizen_profile(filename, &current_citizen) == 0) {
        g_print("Profile updated successfully.\n");
    } else {
        g_print("Error updating citizen profile.\n");
    }
}




void
on_delete_profile_btn_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *delete_warning;
delete_warning = create_delete_warning ();
  gtk_widget_show (delete_warning);
}


void on_update_btn_clicked(GtkButton *button, gpointer user_data)
{
    GtkWidget *treeview; 
    GtkWidget *textview;
    
    // Lookup widgets
    treeview = lookup_widget(GTK_WIDGET(button), "treeview_invoice");
    textview = lookup_widget(GTK_WIDGET(button), "textview_invoice");
    
    if (!treeview || !textview) {
        g_print("Error: Missing treeview or textview widgets.\n");
        return;
    }

    static gboolean columns_added = FALSE;

    if (!columns_added) {
        // Ensure columns are set up only once
        setup_tree_view(GTK_TREE_VIEW(treeview));
        columns_added = TRUE;
    }

    // Create a new GtkListStore with 3 columns
    GtkListStore *store = gtk_list_store_new(3, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_FLOAT);
    GtkTreeIter iter;

    // Array to hold parking data
    parking_data data_array[100];
    int count = read_parking_data("invoice.txt", data_array, 100);
    if (count < 0) {
        g_print("Error: Unable to read parking data.\n");
        return;
    }

    // Populate the GtkListStore and calculate the total cost
    float total_cost = 0;
    for (int i = 0; i < count; i++) {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                           0, data_array[i].duration,  // Column 0
                           1, data_array[i].date,     // Column 1
                           2, data_array[i].cost,     // Column 2
                           -1);

        total_cost += data_array[i].cost;
    }

    // Set the model for the treeview
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store); // Release the reference to the model

    // Display the total cost in the GtkTextView
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview));
    gchar *total_cost_str = g_strdup_printf("%.2f DTN", total_cost);
    gtk_text_buffer_set_text(buffer, total_cost_str, -1);
    g_free(total_cost_str);
}

void
on_okbutton1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

// Get the ID entry widget (assume it's global or accessible)
    GtkWidget *id_entry;
     id_entry= lookup_widget(button, "id_delete");

    // Get the text from the entry
    const char *id_text = gtk_entry_get_text(GTK_ENTRY(id_entry));
    int id_to_delete = atoi(id_text); // Convert to integer

    const char *filename = "citizen_profile.txt";
    int delete_result = delete_citizen_profile(filename, id_to_delete);

    if (delete_result == 0) {
        g_print("Citizen profile with ID %d deleted successfully.\n", id_to_delete);
    } else if (delete_result == -2) {
        g_print("Citizen profile with ID %d not found.\n", id_to_delete);
    } else {
        g_print("An error occurred while deleting the citizen profile.\n");
    }
}



void
on_btn_print_fact_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *invoice;
    invoice = create_invoice ();    
    gtk_widget_show(invoice);
}


void
on_togglebutton2_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_togglebutton1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_helpbutton1_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_cancelbutton1_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_cancelbutton2_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *user_interface;
    GtkWidget *logout;
    
    user_interface = gtk_widget_get_toplevel(GTK_WIDGET(button));
    
    
    if (GTK_IS_WINDOW(user_interface)) {
        gtk_widget_hide(user_interface);
         
        g_print(" window user is now hidden.\n");
    } else {
        g_warning("The widget is not a valid window.");
    }
   /*logout = gtk_widget_get_toplevel(GTK_WIDGET(button));
   if (GTK_IS_WINDOW(logout)) {
        
        gtk_widget_hide(logout); 
        g_print(" window logout is now hidden.\n");
    } else {
        g_warning("The widget is not a valid window.");
    }*/
}


void
on_cancelbutton3_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_okbutton3_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_user_interface_show                 (GtkWidget       *widget,
                                        gpointer         user_data)
{

}


void
on_btn_show_profile_data_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
     GtkWidget *parent_window = GTK_WIDGET(gtk_widget_get_toplevel(GTK_WIDGET(button)));
    GtkWidget *name_textview;
    GtkWidget *surname_textview;
    GtkWidget *email_textview;
    GtkWidget *carbrand_textview;
    GtkWidget *serial_textview;
    GtkWidget *password_entry;
    GtkWidget *color_textview;
    GtkWidget *male_checkbox;
    GtkWidget *female_checkbox;
    GtkWidget *image_widget;
    GtkWidget *errreur;

    // Lookup widgets
    errreur = lookup_widget(parent_window, "erreur");
    name_textview = lookup_widget(parent_window, "textview_name");
    surname_textview = lookup_widget(parent_window, "surname_textview");
    email_textview = lookup_widget(parent_window, "textview_email");
    carbrand_textview = lookup_widget(parent_window, "textview_car_brand");
    serial_textview = lookup_widget(parent_window, "textview_serial");
    password_entry = lookup_widget(parent_window, "entry_passwrd");
    color_textview = lookup_widget(parent_window, "textview_color");
    male_checkbox = lookup_widget(parent_window, "checkmale");
    female_checkbox = lookup_widget(parent_window, "checkfemale");
    image_widget = lookup_widget(parent_window, "pdp");

    // Ensure all widgets are found
    if (!name_textview || !surname_textview || !email_textview || !carbrand_textview || 
        !serial_textview || !password_entry || !color_textview || 
        !male_checkbox || !female_checkbox || !image_widget) {
        g_print("Error: Some widgets not found!\n");
        return;
    }

     // Read citizen profile from file using the logged-in citizen ID
    citizen citizen_data;
    if (logged_in_citizen_id < 0) {
        g_print("Error: Invalid logged-in citizen ID.\n");
  
        return;
    }

    int result = read_citizen_profile_by_id("citizen_profile.txt", logged_in_citizen_id, &citizen_data);
    if (result == 0) {
        g_print("Error: No citizen found with the provided ID: %d\n", logged_in_citizen_id);

        return;
    }

    // Display data in respective widgets
    GtkTextBuffer *buffer;

    // Name
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(name_textview));
    gtk_text_buffer_set_text(buffer, citizen_data.name, -1);

    // Surname
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(surname_textview));
    gtk_text_buffer_set_text(buffer, citizen_data.surname, -1);

    // Email
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(email_textview));
    gtk_text_buffer_set_text(buffer, citizen_data.email, -1);

    // Password
    gtk_entry_set_text(GTK_ENTRY(password_entry), citizen_data.password);

    // Car Brand
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(carbrand_textview));
    gtk_text_buffer_set_text(buffer, citizen_data.car_brand, -1);

    // Serial
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(serial_textview));
    gtk_text_buffer_set_text(buffer, citizen_data.car_serial, -1);

    // Color
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(color_textview));
    gtk_text_buffer_set_text(buffer, citizen_data.color, -1);

    // Gender: Set checkboxes based on gender value
    if (strcmp(citizen_data.gender, "Male") == 0) {
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(male_checkbox), TRUE);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(female_checkbox), FALSE);
    } else if (strcmp(citizen_data.gender, "Female") == 0) {
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(male_checkbox), FALSE);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(female_checkbox), TRUE);
    } else {
        // Default: Uncheck both if gender is unknown
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(male_checkbox), FALSE);
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(female_checkbox), FALSE);
    }

    // Profile picture
    if (citizen_data.profile_picture[0] != '\0') {
        gtk_image_set_from_file(GTK_IMAGE(image_widget), citizen_data.profile_picture);
    } else {
        // If no profile picture, set a default image
        gtk_image_set_from_stock(GTK_IMAGE(image_widget), GTK_STOCK_MISSING_IMAGE, GTK_ICON_SIZE_DIALOG);
    }

    g_print("Citizen profile displayed successfully.\n");
}




void
on_reserv_btn_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_feedback_btn_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_btn_logout_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *login;
  GtkWidget *user_interface;
  login = create_login ();
  gtk_widget_show (login);

// Assuming 'login' is a top-level window
    user_interface = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(user_interface)) {
        gtk_widget_hide(user_interface); // Hide the login window
        g_print("user_interface window is now hidden.\n");
    } else {
        g_warning("The 'user_interface' widget is not a valid window.");
    }
  
}

void setup_tree_view(GtkTreeView *treeview)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;

    // Remove all existing columns from the TreeView
    GList *columns = gtk_tree_view_get_columns(treeview);
    for (GList *iter = columns; iter != NULL; iter = iter->next) {
        gtk_tree_view_remove_column(treeview, GTK_TREE_VIEW_COLUMN(iter->data));
    }
    g_list_free(columns);

    // Column 1: Duration

    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Duration", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(treeview, column);

    // Column 2: Date
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(treeview, column);

    // Column 3: Cost
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Cost", renderer, "text", 2, NULL);
    gtk_tree_view_append_column(treeview, column);
}





void
on_radiomale_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiofemale_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_Addbtn_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_signinbtn_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *addwindow;
    GtkWidget *login;
    const char *filename = "citizen_profile.txt"; 
    citizen new_citizen;

	GtkWidget *parent_window = GTK_WIDGET(gtk_widget_get_toplevel(GTK_WIDGET(button)));
	GtkWidget *entry_id;
	GtkWidget *entry_name;
	GtkWidget *entry_surname;
	GtkWidget *entry_email;
	GtkWidget *entry_password;
	GtkWidget *entry_car_brand;
	GtkWidget *entry_car_serial;
	GtkWidget *entry_color;
	GtkWidget *radio_male;
	GtkWidget *radio_female;
        GtkWidget *file_selector;

    // Retrieve widget pointers
    entry_id = lookup_widget(parent_window, "idadd");
    entry_name = lookup_widget(parent_window, "nameadd");
    entry_surname = lookup_widget(parent_window, "surnameadd");
    entry_email = lookup_widget(parent_window, "emailadd");
    entry_password = lookup_widget(parent_window, "passadd");
    entry_car_brand = lookup_widget(parent_window, "brandadd");
    entry_car_serial = lookup_widget(parent_window, "serialadd");
    entry_color = lookup_widget(parent_window, "coloradd");
    radio_male = lookup_widget(parent_window, "radiomaleadd");
    radio_female = lookup_widget(parent_window, "radiofemaleadd");
    file_selector = lookup_widget(parent_window, "filechooseradd");
    

    // Validate widget pointers
    if (!entry_id || !entry_name || !entry_surname || !entry_email || !entry_password ||
        !entry_car_brand || !entry_car_serial || !entry_color || !radio_male || !radio_female || !file_selector) {
        g_print("Error: Some widgets could not be found.\n");
        return;
    }
 const gchar *pdp_filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(file_selector));
    // Get user input
    const char *id = gtk_entry_get_text(GTK_ENTRY(entry_id));
    const gchar *name = gtk_entry_get_text(GTK_ENTRY(entry_name));
    const gchar *surname = gtk_entry_get_text(GTK_ENTRY(entry_surname));
    const gchar *email = gtk_entry_get_text(GTK_ENTRY(entry_email));
    const gchar *password = gtk_entry_get_text(GTK_ENTRY(entry_password));
    const gchar *car_brand = gtk_entry_get_text(GTK_ENTRY(entry_car_brand));
    const gchar *car_serial = gtk_entry_get_text(GTK_ENTRY(entry_car_serial));
    const gchar *color = gtk_entry_get_text(GTK_ENTRY(entry_color));
    const gchar *gender = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_male)) ? 
                          "Male" : 
                          (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radio_female)) ? "Female" : "");

    

    // Validate user input
    if (strlen(id) == 0 || strlen(name) == 0 || strlen(surname) == 0 || strlen(email) == 0 || 
        strlen(password) == 0 || strlen(car_brand) == 0 || strlen(car_serial) == 0 || strlen(color) == 0 || 
        strlen(gender) == 0) {
        g_print("Error: All fields must be filled out.\n");
        return -1;
    }

    int cin=atoi(id);
    
    // Fill the citizen struct
    new_citizen.id=cin;
    strncpy(new_citizen.name, name, sizeof(new_citizen.name) - 1);
    strncpy(new_citizen.surname, surname, sizeof(new_citizen.surname) - 1);
    strncpy(new_citizen.email, email, sizeof(new_citizen.email) - 1);
    strncpy(new_citizen.password, password, sizeof(new_citizen.password) - 1);
    strncpy(new_citizen.car_brand, car_brand, sizeof(new_citizen.car_brand) - 1);
    strncpy(new_citizen.car_serial, car_serial, sizeof(new_citizen.car_serial) - 1);
    strncpy(new_citizen.color, color, sizeof(new_citizen.color) - 1);
    strncpy(new_citizen.gender, gender, sizeof(new_citizen.gender) - 1);
   if (pdp_filename != NULL) {
        strncpy(new_citizen.profile_picture, pdp_filename, sizeof(new_citizen.profile_picture) - 1);
    }
    
// Save citizen to file
    if (add_citizen(filename, &new_citizen) != 1) {
        g_print("Error: Could not add to the file.\n");
        return;
    }
    g_print("Citizen profile added successfully.\n");
   

    // Window management
    login = create_login();
    gtk_widget_show(login);

    addwindow = gtk_widget_get_toplevel(GTK_WIDGET(button));
    if (GTK_IS_WINDOW(addwindow)) {
        gtk_widget_hide(addwindow);
    } else {
        g_warning("Error: addwindow is not a valid window.");
    }
}



void
on_sinupbtn_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *addwindow;
GtkWidget *login;
addwindow = create_addwindow ();
  gtk_widget_show (addwindow);



  // Assuming 'login' is a top-level window
    login = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(login)) {
        gtk_widget_hide(login); // Hide the login window
        g_print("Login window is now hidden.\n");
    } else {
        g_warning("The 'login' widget is not a valid window.");
    }
}


void
on_loginbtn_clicked(GtkButton *button, gpointer user_data)
{
    /*GtkWidget *parent_window = GTK_WIDGET(gtk_widget_get_toplevel(GTK_WIDGET(button)));
    GtkWidget *entry_id = lookup_widget(parent_window, "idlogin");
    GtkWidget *entry_password = lookup_widget(parent_window, "passlogin");

    if (!entry_id || !entry_password) {
        g_print("Error: Widgets for ID and password not found.\n");
        return;
    }

    const gchar *id_text = gtk_entry_get_text(GTK_ENTRY(entry_id));
    const gchar *password_text = gtk_entry_get_text(GTK_ENTRY(entry_password));

    // Validate user input
    if (strlen(id_text) == 0 || strlen(password_text) == 0) {
        g_print("Error: ID and password fields must not be empty.\n");
        return;
    }

    // Convert ID to integer
    int id = atoi(id_text);
    if (id == 0 && strcmp(id_text, "0") != 0) {
        g_print("Error: Invalid ID format.\n");
        return;
    }
  
    const char *filename = "citizen_profile.txt";
    citizen citizen_data_array[1]; // Create an array to hold the results (one citizen)
    int max_results = 1; // We expect only one result, since IDs should be unique

    // Search for citizen by ID
    int result = search_all_citizens_by_id(filename, id, citizen_data_array, max_results);
    if (result == -1) {
        g_print("Error: Unable to open the citizen file.\n");
        return;
    } else if (result == 0) {
        g_print("Error: No citizen found with the provided ID.\n");
        return;
    }else{logged_in_citizen_id = id;}

    // Verify password
    if (strcmp(citizen_data_array[0].password, password_text) == 0) {
        g_print("Login successful. Welcome, %s %s!\n", citizen_data_array[0].name, citizen_data_array[0].surname);

        // Save the logged-in ID globally
        logged_in_citizen_id = id;

        // Create and show the new user interface window
        GtkWidget *User = create_User();
        gtk_widget_show(User);

        // Hide the login window
        GtkWidget *login = gtk_widget_get_toplevel(GTK_WIDGET(button));
        if (GTK_IS_WINDOW(login)) {
            gtk_widget_hide(login);
        } else {
            g_warning("Error: login_window is not a valid window.");
        }
    } else {
        g_print("Error: Incorrect password.\n");
    }
}*/


    GtkWidget *parent_window = GTK_WIDGET(gtk_widget_get_toplevel(GTK_WIDGET(button)));
    GtkWidget *entry_id = lookup_widget(parent_window, "idlogin");
    GtkWidget *entry_password = lookup_widget(parent_window, "passlogin");
    GtkWidget *errorrr = lookup_widget(parent_window, "erreur");

    if (!entry_id || !entry_password) {
        g_print("Error: Widgets for ID and password not found.\n");
        return;
    }

    const gchar *id_text = gtk_entry_get_text(GTK_ENTRY(entry_id));
    const gchar *password_text = gtk_entry_get_text(GTK_ENTRY(entry_password));

    // Validate user input
    if (strlen(id_text) == 0 || strlen(password_text) == 0) {
        g_print("Error: ID and password fields must not be empty.\n");
        return;
    }

    // Check if admin credentials are entered
    if (strcmp(id_text, "admin") == 0 && strcmp(password_text, "helloworld") == 0) {
        g_print("Admin login successful. Welcome, Admin!\n");

        // Create and show the Admin window
        GtkWidget *Admin = create_Admin(); // Assuming you have a function to create the Admin window
        gtk_widget_show(Admin);

        // Hide the login window
        GtkWidget *login = gtk_widget_get_toplevel(GTK_WIDGET(button));
        if (GTK_IS_WINDOW(login)) {
            gtk_widget_hide(login);
        } else {
            g_warning("Error: login_window is not a valid window.");
        }

        return; // Exit after handling admin login
    }

    // Convert ID to integer
    int id = atoi(id_text);
    if (id == 0 && strcmp(id_text, "0") != 0) {
        g_print("Error: Invalid ID format.\n");
 gtk_label_set_markup(GTK_LABEL(errorrr), "<span foreground='RED'font='13'>Enter a VALID ID !</span>");
        return;
    }

    const char *filename = "citizen_profile.txt";
    citizen citizen_data_array[1]; // Create an array to hold the results (one citizen)
    int max_results = 1; // We expect only one result, since IDs should be unique

    // Search for citizen by ID
    int result = search_all_citizens_by_id(filename, id, citizen_data_array, max_results);
    if (result == -1) {
        g_print("Error: Unable to open the citizen file.\n");
        return;
    } else if (result == 0) {
        g_print("Error: No citizen found with the provided ID.\n");
 gtk_label_set_markup(GTK_LABEL(errorrr), "<span foreground='RED'font='13'>This ID does not exist !</span>");
        return;
    }

    // Verify password
    if (strcmp(citizen_data_array[0].password, password_text) == 0) {
        g_print("Login successful. Welcome, %s %s!\n", citizen_data_array[0].name, citizen_data_array[0].surname);

        // Save the logged-in ID globally
        logged_in_citizen_id = id;

        // Create and show the User window
        GtkWidget *User = create_User();
        gtk_widget_show(User);

        // Hide the login window
        GtkWidget *login = gtk_widget_get_toplevel(GTK_WIDGET(button));
        if (GTK_IS_WINDOW(login)) {
            gtk_widget_hide(login);
        } else {
            g_warning("Error: login_window is not a valid window.");
        }
    } else {
        g_print("Error: Incorrect password.\n");
 gtk_label_set_markup(GTK_LABEL(errorrr), "<span foreground='RED'font='13'>Incorrect password !</span>");
    }
}



void
on_adminbtn_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_clientbtn_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *login , *welcome;
login = create_login ();
  gtk_widget_show (login);

    welcome = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(welcome)) {
        gtk_widget_hide(welcome); // Hide the login window
        g_print("welcome window is now hidden.\n");
    } else {
        g_warning("The 'window' widget is not a valid window.");
    }
}


void
on_backaddtologin_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *addwindow , *login;
login = create_login ();
  gtk_widget_show (login);

    addwindow = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(addwindow)) {
        gtk_widget_hide(addwindow); // Hide the login window
        g_print("addwindow is now hidden.\n");
    } else {
        g_warning("The 'addwindow' widget is not a valid window.");
    }
}


void
on_backlogintowelcome_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *login , *welcome;
welcome = create_welcome ();
  gtk_widget_show (welcome);

    login = gtk_widget_get_toplevel(GTK_WIDGET(button));

    // Check if 'login' is a valid window
    if (GTK_IS_WINDOW(login)) {
        gtk_widget_hide(login); // Hide the login window
        g_print("login window is now hidden.\n");
    } else {
        g_warning("The login widget is not a valid window.");
    }

}




void
on_codebar_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *qrcode;
   qrcode = create_qrcode ();
   gtk_widget_show (qrcode);
}



