#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#include <stdbool.h>
#include "avis.h"

int idav() {
    srand(time(NULL)); // Initialisation de la graine pour les nombres aléatoires
    int id;
    id = 100000 + rand() % 900000; // Génère un ID aléatoire à 8 chiffres
    // Vérifie si l'ID est déjà dans le fichier
    return id;

}


void obtenirDateActuelle(char *dateActuelle) {
    time_t t = time(NULL);               // Obtenir l'heure actuelle
    struct tm tm = *localtime(&t);      // Convertir en temps local
    // Format : "DD-MM-YYYY HH:MM:SS"
    sprintf(dateActuelle, "%02d-%02d-%d/%02d:%02d:%02d",
            tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900,
            tm.tm_hour, tm.tm_min, tm.tm_sec);
}

void ajouteravis(Avis avis) {
    FILE *file = fopen("avis.txt", "a");
    FILE*f=fopen("review.txt","a");
    if (file == NULL) {
        printf("Erreur d'ouverture du fichier\n");
        return;
    }
if (f == NULL) {
        printf("Erreur d'ouverture du fichier review.txt\n");
        return;
    }
avis.idavis=idav();
    // Écriture dans le fichier
    fprintf(file, "%d %s %s %s %d %s %s\n",
            avis.idavis, avis.nom, avis.prenom,
            avis.description, avis.Rate, avis.sujet, avis.date);

    fclose(file);
fprintf(f,"%s\n",avis.description);
fclose(f);
}

void afficher_avis(GtkWidget *tree_view) {
    // Dissocier le modèle précédent pour éviter des conflits
    gtk_tree_view_set_model(GTK_TREE_VIEW(tree_view), NULL);

    // Créer le modèle GtkListStore avec 8 colonnes
    GtkListStore *store = gtk_list_store_new(7, 
                                             G_TYPE_INT,    // ID Reservation
                                             G_TYPE_STRING, // Prenom
                                             G_TYPE_STRING,    // Nom
                                             G_TYPE_STRING, // Sexe
                                             G_TYPE_INT,    // Jour
                                             G_TYPE_STRING,    // Mois
                                             G_TYPE_STRING);   // Annee

    FILE *file = fopen("avis.txt", "r");
    if (!file) {
        g_printerr("Erreur : Impossible d'ouvrir res.txt.\n");
        return;
    }

    Avis avis;
    char line[1024];
    int count = 0;
    while (fgets(line, sizeof(line), file)) {
        // Supprimer le caractère de nouvelle ligne
        line[strcspn(line, "\n")] = 0;

        // Parser la ligne
        int n = sscanf(line, "%d %49s %49s %499s %d %49s %49s\n",
            &avis.idavis,avis.nom, avis.prenom,
            avis.description, &avis.Rate, avis.sujet, avis.date);

        if (n == 7) { // Vérifier que tous les champs ont été lus
            GtkTreeIter iter;
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                               0, avis.idavis,
                               1, avis.nom,
                               2, avis.prenom,
                               3, avis.sujet,
                               4, avis.Rate,
                               5, avis.description,
                               6, avis.date,
                               -1);
            count++;
        } else {
            g_printerr("Erreur de format dans une ligne du fichier : %s\n", line);
        }
    }
    fclose(file);

    if (count == 0) {
        g_print("Aucune réservation trouvée dans le fichier.\n");
    } else {
        g_print("%d avis chargée(s) depuis le fichier.\n", count);
    }

    // Ajouter les colonnes au TreeView si elles n'existent pas déjà
    if (g_list_length(gtk_tree_view_get_columns(GTK_TREE_VIEW(tree_view))) == 0) {
        GtkCellRenderer *renderer = gtk_cell_renderer_text_new();

        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("ID Review", renderer, "text", 0, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Name", renderer, "text", 1, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Surname", renderer, "text", 2, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("About", renderer, "text", 3, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Evaluation", renderer, "text", 4, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Description", renderer, "text", 5, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Date", renderer, "text", 6, NULL));
    }

    // Appliquer le modèle au TreeView
    gtk_tree_view_set_model(GTK_TREE_VIEW(tree_view), GTK_TREE_MODEL(store));

    // Libérer le modèle
    g_object_unref(store);
}
/*gboolean validate_input(const gchar *input, const gchar *regex, const gchar *error_message) {
    if (!g_regex_match_simple(regex, input, 0, 0)) {
        g_print("%s\n", error_message);
        return FALSE;
    }
    return TRUE;
}*/
int comparer_croissant(const void *a, const void *b) {
    Avis *avisA = (Avis *)a;
    Avis *avisB = (Avis *)b;
    return avisA->Rate - avisB->Rate;
}

// Fonction pour comparer les évaluations (Rate) en ordre décroissant
int comparer_decroissant(const void *a, const void *b) {
    Avis *avisA = (Avis *)a;
    Avis *avisB = (Avis *)b;
    return avisB->Rate - avisA->Rate;
}

// Fonction pour lire les avis depuis un fichier
int lire_fichier(const char *nom_fichier, Avis avis[], int taille_max) {
    FILE *fichier = fopen(nom_fichier, "r");
    if (!fichier) {
        perror("Erreur lors de l'ouverture du fichier");
        return -1;
    }

    int count = 0;
    while (fscanf(fichier, "%d %49s %49s %499s %d %49s %49s\n",
                  &avis[count].idavis,
                avis[count].nom,
                avis[count].prenom,
                avis[count].description,
                &avis[count].Rate,
                avis[count].sujet,
                avis[count].date) == 7) {
        count++;
        if (count >= taille_max) break;
    }

    fclose(fichier);
    return count;
}

// Fonction pour écrire les avis triés dans le fichier
void ecrire_fichier(const char *nom_fichier, Avis avis[], int count) {
    FILE *fichier = fopen(nom_fichier, "w");
    if (!fichier) {
        perror("Erreur lors de l'ouverture du fichier en écriture");
        return;
    }

    for (int i = 0; i < count; i++) {
        fprintf(fichier, "%d %s %s %s %d %s %s\n",
                avis[i].idavis,
                avis[i].nom,
                avis[i].prenom,
                avis[i].description,
                avis[i].Rate,
                avis[i].sujet,
                avis[i].date);
    }

    fclose(fichier);
}




//progressbar


// Fonction appelée périodiquement pour mettre à jour la barre de progression
gboolean update_progresss(gpointer user_data) {
    ProgressData *data = (ProgressData *)user_data;

    // Calcule la fraction (de 0.0 à 1.0)
    double fraction = (double)data->elapsed_steps / 5.0; // 90 étapes en 9 secondes (100ms chaque)

    gtk_progress_bar_set_fraction(data->progress_bar, fraction);

    // Incrémente le nombre d'étapes
    data->elapsed_steps++;

    // Vérifie si le chargement est terminé
    if (data->elapsed_steps > 5) {
        g_print("Progress complete!\n");
        return FALSE; // Arrête le timer
    }

    return TRUE; // Continue d'exécuter la fonction
}

