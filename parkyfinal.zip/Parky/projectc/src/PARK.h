
typedef struct {
    int ID_service;
    char description[100]; // Adjust size as necessary
    char Prix[10];         // Changed to string to hold price
    char type_service[10]; // NORMAL or VIP
    char offre[10];        // Offer percentage (VIP only)
} Serv;

#define FILENAME "/home/eya/Desktop/Parky/projectc/Serv.txt"


void saisir(Serv *serv);
void ajouters(Serv serv);
void modifiers(int id);
void supprimers(int id);
void recherchers(int id);
void affichers();



