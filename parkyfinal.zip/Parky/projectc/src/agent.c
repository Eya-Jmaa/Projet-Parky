#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include <string.h>
#include <curl/curl.h>
#include <stdbool.h>
#include "agent.h"

int id_existe(int id_modif) {
    FILE *file = fopen("agents.txt", "r");
    if (!file) {
        perror("Erreur à l'ouverture du fichier agents.txt");
        return 0; // On considère que l'ID n'existe pas en cas d'erreur de fichier
    }

    Agent agent;
agent.idparking=1;
strcpy(agent.statut,"unassigned");
    while (fscanf(file,"%d %d %d %49s %49s %199s %199s %d-%d-%d %49s %d %19s %99s %99s %499s\n",
            &agent.idagent ,&agent.idparking,&agent.cin,agent.nom, agent.prenom, agent.adresse,agent.role,
            &agent.jour, &agent.mois, &agent.annee,agent.sexe, &agent.tel,agent.exp,agent.statut,agent.email,agent.image)== 16) {
        if (agent.idagent == id_modif) {
            fclose(file);
            return 1; // ID trouvé
        }
    }

    fclose(file);
    return 0; // ID non trouvé
}

int id() {
    srand(time(NULL)); // Initialisation de la graine pour les nombres aléatoires
    int id;
    id = 100000 + rand() % 900000; // Génère un ID aléatoire à 8 chiffres
    // Vérifie si l'ID est déjà dans le fichier
    return id;
}
void ajouter(Agent agent) {
    FILE *file = fopen("agents.txt", "a");
    FILE *fichier = fopen("emails.txt", "a");

    if (file == NULL) {
        printf("Erreur d'ouverture du fichier\n");
        return;
    }

if (fichier == NULL) {
        printf("Erreur d'ouverture du fichier des emails\n");
        return;
    }

agent.idagent=id();
strcpy(agent.statut,"unassigned");
agent.idparking=1;
    fprintf(file, "%d %d %d %s %s %s %s %d-%d-%d %s %d %s %s %s %s\n",
            agent.idagent, agent.idparking, agent.cin, agent.nom, agent.prenom, agent.adresse, agent.role,
            agent.jour, agent.mois, agent.annee, agent.sexe, agent.tel, agent.exp, agent.statut,agent.email,agent.image);
fclose(file);

 fprintf(fichier,"%s\n",agent.email);

  fclose(fichier); 
 
}

/*void ajouter(Agent agent) {
    // Ouvrir ou créer les fichiers
    FILE *file = fopen("agents.txt", "a");
    FILE *fichier = fopen("emails.txt", "a");

    // Vérifier si les fichiers s'ouvrent correctement
    if (file == NULL) {
        perror("Erreur d'ouverture du fichier agents.txt");
        return;
    }

    if (fichier == NULL) {
        perror("Erreur d'ouverture du fichier emails.txt");
        fclose(file); // Fermer le fichier ouvert avant de quitter
        return;
    }

    // Ajouter un ID généré à l'agent et initialiser certains champs
    agent.idagent = id();
    strcpy(agent.statut, "unassigned");
    agent.idparking = 1;

    // Écrire les données de l'agent dans le fichier agents.txt
    fprintf(file, "%d %d %d %s %s %s %s %d-%d-%d %s %d %s %s %s %s\n",
            agent.idagent, agent.idparking, agent.cin, agent.nom, agent.prenom,
            agent.adresse, agent.role, agent.jour, agent.mois, agent.annee,
            agent.sexe, agent.tel, agent.exp, agent.statut, agent.email, agent.image);

    // Ajouter l'email de l'agent dans le fichier emails.txt
    fprintf(fichier, "%s\n", agent.email);

    // Fermer les fichiers
    fclose(file);
    fclose(fichier);
}*/





/*void rechercher_agent(GtkTreeView *tree_view, const char *prenom_text, const char *nom_text, int id_recherchepark, const char *role_recherche) {
    Agent agent;
    GtkListStore *store = gtk_list_store_new(9, 
                                             G_TYPE_INT,    // ID Agent
                                             G_TYPE_STRING, // Nom
                                             G_TYPE_STRING, // Prénom
                                             G_TYPE_STRING, // Adresse
                                             G_TYPE_STRING, // Email
                                             G_TYPE_STRING, // Rôle
                                             G_TYPE_STRING, // Expérimenté
                                             G_TYPE_STRING, // Statut
                                             G_TYPE_INT);   // ID Parking

    FILE *file = fopen("agents.txt", "r");
    if (!file) {
        g_printerr("Erreur : impossible d'ouvrir le fichier agents.txt.\n");
        return;
    }

    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        // Parse la ligne
        if (sscanf(line, "%d %d %d %49s %49s %199s %199s %d-%d-%d %49s %d %19s %99s %99s %499s %499s",
                   &agent.idagent, &agent.idparking, &agent.cin, agent.nom, agent.prenom, agent.adresse, agent.role,
                   &agent.jour, &agent.mois, &agent.annee, agent.sexe, &agent.tel, agent.exp, agent.statut,
                   agent.email, agent.image, agent.experience) == 17) {
            // Vérifie les critères de recherche
            if ((id_recherchepark > 0 && agent.idparking == id_recherchepark) ||
                (strcmp(role_recherche, "") != 0 && strcmp(agent.role, role_recherche) == 0) ||
                (strcmp(prenom_text, "") != 0 && strcmp(agent.prenom, prenom_text) == 0) ||
                (strcmp(nom_text, "") != 0 && strcmp(agent.nom, nom_text) == 0)) {

                GtkTreeIter iter;
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store, &iter,
                                   0, agent.idagent,
                                   1, agent.nom,
                                   2, agent.prenom,
                                   3, agent.adresse,
                                   4, agent.email,
                                   5, agent.role,
                                   6, agent.exp,
                                   7, agent.statut,
                                   8, agent.idparking,
                                   -1);
            }
        } else {
            g_printerr("Erreur de format dans la ligne suivante : %s\n", line);
        }
    }

    fclose(file);

    // Assigner le modèle au TreeView
    gtk_tree_view_set_model(tree_view, GTK_TREE_MODEL(store));

    // Libérer le modèle
    g_object_unref(store);
}*/

void rechercher_agent(GtkTreeView *tree_view, const char *prenom_text, const char *nom_text, int id_recherchepark, const char *role_recherche) {
    Agent agent;
    GtkListStore *store = gtk_list_store_new(9, 
                                             G_TYPE_INT,    // ID Agent
                                             G_TYPE_STRING, // Nom
                                             G_TYPE_STRING, // Prénom
                                             G_TYPE_STRING, // Adresse
                                             G_TYPE_STRING, // Email
                                             G_TYPE_STRING, // Rôle
                                             G_TYPE_STRING, // Expérimenté
                                             G_TYPE_STRING, // Statut
                                             G_TYPE_INT);   // ID Parking

    FILE *file = fopen("agents.txt", "r");
    if (!file) {
        g_printerr("Erreur : impossible d'ouvrir le fichier agents.txt.\n");
        return;
    }

    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        // Parse la ligne
        if (sscanf(line, "%d %d %d %49s %49s %199s %199s %d-%d-%d %49s %d %19s %99s %99s %499s",
                   &agent.idagent, &agent.idparking, &agent.cin, agent.nom, agent.prenom, agent.adresse, agent.role,
                   &agent.jour, &agent.mois, &agent.annee, agent.sexe, &agent.tel, agent.exp, agent.statut,
                   agent.email, agent.image) == 16) {

            // Vérification des critères de recherche
            int match = 0;

            if (id_recherchepark > 0 && agent.idparking == id_recherchepark) {
                match = 1; // Recherche par ID Parking
            } 
            else if (strcmp(role_recherche, "") != 0 && strcmp(agent.role, role_recherche) == 0) {
                match = 1; // Recherche par rôle
            } 
            else if (strcmp(prenom_text, "") != 0 && strcmp(nom_text, "") != 0) {
                // Recherche stricte par combinaison nom + prénom
                if (strcmp(agent.prenom, prenom_text) == 0 && strcmp(agent.nom, nom_text) == 0) {
                    match = 1;
                }
            } 
            else if (strcmp(prenom_text, "") != 0) {
                // Recherche uniquement par prénom
                if (strcmp(agent.prenom, prenom_text) == 0) {
                    match = 1;
                }
            } 
            else if (strcmp(nom_text, "") != 0) {
                // Recherche uniquement par nom
                if (strcmp(agent.nom, nom_text) == 0) {
                    match = 1;
                }
            }

            // Si un critère est rempli, ajouter l'agent au TreeView
            if (match) {
                GtkTreeIter iter;
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store, &iter,
                                   0, agent.idagent,
                                   1, agent.nom,
                                   2, agent.prenom,
                                   3, agent.adresse,
                                   4, agent.email,
                                   5, agent.role,
                                   6, agent.exp,
                                   7, agent.statut,
                                   8, agent.idparking,
                                   -1);
            }
        } else {
            g_printerr("Erreur de format dans la ligne suivante : %s\n", line);
        }
    }

    fclose(file);

    // Assigner le modèle au TreeView
    gtk_tree_view_set_model(tree_view, GTK_TREE_MODEL(store));

    // Libérer le modèle
    g_object_unref(store);
}




void afficher_agents(GtkWidget *tree_view) {
    // Dissocier le modèle précédent pour éviter des conflits
    gtk_tree_view_set_model(GTK_TREE_VIEW(tree_view), NULL);

    // Créer le modèle GtkListStore avec 10 colonnes
    GtkListStore *store = gtk_list_store_new(9, 
                                             G_TYPE_INT,    // ID Agent
                                             G_TYPE_STRING, // Nom
                                             G_TYPE_STRING, // Prénom
                                             G_TYPE_STRING, // Adresse
                                             G_TYPE_STRING, // Email
                                             G_TYPE_STRING, // Rôle
                                             G_TYPE_STRING, // experimenté
                                             G_TYPE_STRING, // statut
                                             G_TYPE_INT);   // ID Parking

    FILE *file = fopen("agents.txt", "r");
    if (!file) {
        g_printerr("Erreur : Impossible d'ouvrir agents.txt.\n");
        return;
    }

    Agent agent;
    char line[1024];
    int count = 0;
strcpy(agent.statut,"unassigned");
agent.idparking=1;
    while (fgets(line, sizeof(line), file)) {
        // Supprimer le caractère de nouvelle ligne
        line[strcspn(line, "\n")] = 0;

        // Parser la ligne
        int n = sscanf(line, "%d %d %d %49s %49s %199s %199s %d-%d-%d %49s %d %19s %99s %99s %499s", 
            &agent.idagent, &agent.idparking, &agent.cin, agent.nom, agent.prenom, agent.adresse, agent.role, 
            &agent.jour, &agent.mois, &agent.annee, agent.sexe, &agent.tel, agent.exp, agent.statut,agent.email,agent.image);

        if (n == 16) { // Vérifier que tous les champs ont été lus
            GtkTreeIter iter;
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                               0, agent.idagent,
                               1, agent.nom,
                               2, agent.prenom,
                               3, agent.adresse,
                               4, agent.email,
                               5, agent.role,
                               6, agent.exp,
                               7, agent.statut,
                               8, agent.idparking,
                               -1);
            count++;
        } else {
            g_printerr("Erreur de format dans une ligne du fichier : %s\n", line);
        }
    }
    fclose(file);

    if (count == 0) {
        g_print("Aucun agent trouvé dans le fichier.\n");
    } else {
        g_print("%d agent(s) chargé(s) depuis le fichier.\n", count);
    }

    // Ajouter les colonnes au TreeView si elles n'existent pas déjà
    if (g_list_length(gtk_tree_view_get_columns(GTK_TREE_VIEW(tree_view))) == 0) {
        GtkCellRenderer *renderer = gtk_cell_renderer_text_new();

        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("ID Agent", renderer, "text", 0, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Name", renderer, "text", 1, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Surname", renderer, "text", 2, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Adress", renderer, "text", 3, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Email", renderer, "text", 4, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Role", renderer, "text", 5, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Experienced", renderer, "text", 6, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("State", renderer, "text", 7, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("ID Parking", renderer, "text", 8, NULL));
       
    }

    // Appliquer le modèle au TreeView
    gtk_tree_view_set_model(GTK_TREE_VIEW(tree_view), GTK_TREE_MODEL(store));

    // Libérer le modèle
    g_object_unref(store);
}




void afficher_res(GtkWidget *tree_view) {
    // Dissocier le modèle précédent pour éviter des conflits
    gtk_tree_view_set_model(GTK_TREE_VIEW(tree_view), NULL);

    // Créer le modèle GtkListStore avec 8 colonnes
    GtkListStore *store = gtk_list_store_new(8, 
                                             G_TYPE_INT,    // ID Reservation
                                             G_TYPE_STRING, // Nom
                                             G_TYPE_STRING, // Prenom
                                             G_TYPE_INT,    // CIN
                                             G_TYPE_STRING, // Sexe
                                             G_TYPE_INT,    // Jour
                                             G_TYPE_INT,    // Mois
                                             G_TYPE_INT);   // Annee

    FILE *file = fopen("res.txt", "r");
    if (!file) {
        g_printerr("Erreur : Impossible d'ouvrir res.txt.\n");
        return;
    }

    Reservation res;
    char line[1024];
    int count = 0;
    while (fgets(line, sizeof(line), file)) {
        // Supprimer le caractère de nouvelle ligne
        line[strcspn(line, "\n")] = 0;

        // Parser la ligne
        int n = sscanf(line, "%d %49s %49s %d %19s %d-%d-%d",
                  &res.idres, res.nom, res.prenom, &res.cin, res.sexe, 
                  &res.jour, &res.mois, &res.annee);

        if (n == 8) { // Vérifier que tous les champs ont été lus
            GtkTreeIter iter;
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                               0, res.idres,
                               1, res.nom,
                               2, res.prenom,
                               3, res.cin,
                               4, res.sexe,
                               5, res.jour,
                               6, res.mois,
                               7, res.annee,
                               -1);
            count++;
        } else {
            g_printerr("Erreur de format dans une ligne du fichier : %s\n", line);
        }
    }
    fclose(file);

    if (count == 0) {
        g_print("Aucune réservation trouvée dans le fichier.\n");
    } else {
        g_print("%d réservation(s) chargée(s) depuis le fichier.\n", count);
    }

    // Ajouter les colonnes au TreeView si elles n'existent pas déjà
    if (g_list_length(gtk_tree_view_get_columns(GTK_TREE_VIEW(tree_view))) == 0) {
        GtkCellRenderer *renderer = gtk_cell_renderer_text_new();

        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("ID Reservation", renderer, "text", 0, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Name", renderer, "text", 1, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Surname", renderer, "text", 2, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("CIN", renderer, "text", 3, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Sex", renderer, "text", 4, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Day", renderer, "text", 5, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Month", renderer, "text", 6, NULL));
        gtk_tree_view_append_column(GTK_TREE_VIEW(tree_view),
                                    gtk_tree_view_column_new_with_attributes("Year", renderer, "text", 7, NULL));
    }

    // Appliquer le modèle au TreeView
    gtk_tree_view_set_model(GTK_TREE_VIEW(tree_view), GTK_TREE_MODEL(store));

    // Libérer le modèle
    g_object_unref(store);
}


/*void modifier(Agent agent_modif) {
    FILE *file = fopen("agents.txt", "r");
    FILE *temp_file = fopen("temp.txt", "w");

    if (file == NULL || temp_file == NULL) {
        printf("Erreur d'ouverture du fichier\n");
        if (file) fclose(file);
        if (temp_file) fclose(temp_file);
        return;
    }

    Agent agent;
    int found = 0;

    // Lecture ligne par ligne
    while (fscanf(file, "%d %d %d %49s %49s %199s %199s %d-%d-%d %49s %d %19s %499s %99s", 
                  &agent.idagent, &agent.idparking, &agent.cin, 
                  agent.nom, agent.prenom, agent.adresse, agent.role, 
                  &agent.jour, &agent.mois, &agent.annee, 
                  agent.sexe, &agent.tel, agent.exp, 
                  agent.experience, agent.email) == 15) {
        if (agent.idagent == agent_modif.idagent) {
            // Agent trouvé, mise à jour des informations
            found = 1;
            agent = agent_modif; // Remplacer toutes les données
        }
        // Écrire dans le fichier temporaire
        fprintf(temp_file, "%d %d %d %s %s %s %s %d-%d-%d %s %d %s %s %s\n",
                agent.idagent, agent.idparking, agent.cin, 
                agent.nom, agent.prenom, agent.adresse, agent.role, 
                agent.jour, agent.mois, agent.annee, 
                agent.sexe, agent.tel, agent.exp, 
                agent.experience, agent.email);
    }

    fclose(file);
    fclose(temp_file);

    if (found) {
        // Remplacer l'ancien fichier par le fichier temporaire
        remove("agents.txt");
        rename("temp.txt", "agents.txt");
        printf("Agent modifié avec succès.\n");
    } else {
        // Aucun agent trouvé avec l'id donné
        remove("temp.txt");
        printf("Agent avec l'ID %d introuvable.\n", agent_modif.idagent);
    }
}*/


void modifier(Agent agent_modif) {
    FILE *file = fopen("agents.txt", "r");
    FILE *temp_file = fopen("temp.txt", "w");

    if (file == NULL || temp_file == NULL) {
        printf("Erreur d'ouverture du fichier\n");
        if (file) fclose(file);
        if (temp_file) fclose(temp_file);
        return;
    }

    Agent agent;
    int found = 0;
strcpy(agent.statut,"unassigned");


    while (fscanf(file, "%d %d %d %49s %49s %199s %199s %d-%d-%d %49s %d %19s %99s %99s %499s", 
                  &agent.idagent, &agent.idparking, &agent.cin, 
                  agent.nom, agent.prenom, agent.adresse, agent.role, 
                  &agent.jour, &agent.mois, &agent.annee, 
                  agent.sexe, &agent.tel, agent.exp, 
                  agent.statut,agent.email,agent.image) == 16) {
        if (agent.idagent == agent_modif.idagent) {
            // Mise à jour des informations
            found = 1;
            agent = agent_modif;
            
        }
agent.idparking=1;
        fprintf(temp_file, "%d %d %d %s %s %s %s %d-%d-%d %s %d %s %s %s %s\n",
                agent.idagent, agent.idparking, agent.cin, 
                agent.nom, agent.prenom, agent.adresse, agent.role, 
                agent.jour, agent.mois, agent.annee, 
                agent.sexe, agent.tel, agent.exp, 
                agent.statut,agent.email,agent.image);
    }

    fclose(file);
    fclose(temp_file);

    if (found) {
        remove("agents.txt");
        rename("temp.txt", "agents.txt");
    } else {
        remove("temp.txt");
        printf("Agent avec l'ID %d introuvable.\n", agent_modif.idagent);
    }
}

Agent rechercher_agent_par_id(int id_agent) {
    FILE *file = fopen("agents.txt", "r");
    Agent agent;
agent.idparking=1;
strcpy(agent.statut,"unassigned");
    agent.idagent = -1; // Valeur par défaut si l'agent n'est pas trouvé

    if (file == NULL) {
        printf("Erreur d'ouverture du fichier\n");
        return agent;
    }

    while (fscanf(file, "%d %d %d %49s %49s %199s %199s %d-%d-%d %49s %d %19s %99s %99s %499s",
                  &agent.idagent, &agent.idparking, &agent.cin,
                  agent.nom, agent.prenom, agent.adresse, agent.role,
                  &agent.jour, &agent.mois, &agent.annee,
                  agent.sexe, &agent.tel, agent.exp,
                  agent.statut,agent.email,agent.image) == 16) {
        if (agent.idagent == id_agent) {
            fclose(file);
            return agent;
        }
    }

    fclose(file);
    return agent;
}

int get_role_index(const char *role) {
    if (strcmp(role, "Contrôle_des_entrées_et_sorties") == 0) return 0;
    if (strcmp(role, "Sécurité") == 0) return 1;
    if (strcmp(role, "Responsable_des_paiements") == 0) return 2;
    if (strcmp(role, "Agent_de_maintenance") == 0) return 3;
    if (strcmp(role, "Responsable_des_abonnements") == 0) return 4;
    if (strcmp(role, "Assistant_clientèle") == 0) return 5;
    if (strcmp(role, "Superviseur_de_parking") == 0) return 6;
    if (strcmp(role, "Technicien_de_surveillance") == 0) return 7;
    if (strcmp(role, "Agent_polyvalent") == 0) return 8;
    if (strcmp(role, "Responsable_des_réservations") == 0) return 9;
    if (strcmp(role, "Patrouilleur") == 0) return 10;
    if (strcmp(role, "Gestionnaire_de_trafic") == 0) return 11;
    if (strcmp(role, "Opérateur_de_bornes_automatiques") == 0) return 12;
    if (strcmp(role, "Nettoyage") == 0) return 13;
    if (strcmp(role, "Coordonnateur_des_urgences") == 0) return 14;
    return -1; // Rôle non trouvé
}

void envoyer_email(const char *destinataire, const char *sujet, const char *message) {
    CURL *curl;
    CURLcode res;

    const char *expediteur = "ayaajmaa@gmail.com"; // Remplacez par votre adresse Gmail
    const char *password = "xrdf lfph sofv aers";  // Mot de passe d'application

    struct curl_slist *recipients = NULL;

    // Préparation du corps de l'e-mail
    char email_body[2048];
    snprintf(email_body, sizeof(email_body),
             "To: %s\r\n"
             "From: %s\r\n"
             "Subject: %s\r\n"
             "\r\n" // Fin des en-têtes
             "%s\r\n", // Corps du message
             destinataire, expediteur, sujet, message);

    // Initialisation de libcurl
    curl = curl_easy_init();
    if (curl) {
        // Configurer le serveur SMTP de Gmail
        curl_easy_setopt(curl, CURLOPT_URL, "smtp://smtp.gmail.com:587");

        // Activer STARTTLS
        curl_easy_setopt(curl, CURLOPT_USE_SSL, CURLUSESSL_ALL);

        // Fournir les identifiants
        curl_easy_setopt(curl, CURLOPT_USERNAME, expediteur);
        curl_easy_setopt(curl, CURLOPT_PASSWORD, password);

        // Adresse de l'expéditeur
        curl_easy_setopt(curl, CURLOPT_MAIL_FROM, expediteur);

        // Destinataire
        recipients = curl_slist_append(recipients, destinataire);
        curl_easy_setopt(curl, CURLOPT_MAIL_RCPT, recipients);

        // Corps de l'e-mail
        curl_easy_setopt(curl, CURLOPT_READFUNCTION, NULL);
        curl_easy_setopt(curl, CURLOPT_READDATA, email_body);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, email_body);

        // Mode verbose pour le débogage
        curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);

        // Envoyer l'e-mail
        res = curl_easy_perform(curl);
        if (res != CURLE_OK) {
            fprintf(stderr, "Erreur lors de l'envoi de l'e-mail : %s\n", curl_easy_strerror(res));
        } else {
            printf("E-mail envoyé avec succès à %s\n", destinataire);
        }

        // Libérer les ressources
        curl_slist_free_all(recipients);
        curl_easy_cleanup(curl);
    } else {
        fprintf(stderr, "Erreur d'initialisation de libcurl\n");
    }
}


gboolean validate_input(const gchar *input, const gchar *regex, const gchar *error_message) {
    if (!g_regex_match_simple(regex, input, 0, 0)) {
        g_print("%s\n", error_message);
        return FALSE;
    }
    return TRUE;
}

// Comparaison pour un tri croissant par nom
int comparer_croissant_nom(const void *a, const void *b) {
    Agent *agentA = (Agent *)a;
    Agent *agentB = (Agent *)b;
    return strcmp(agentA->nom, agentB->nom); // Comparaison lexicographique des noms
}

// Comparaison pour un tri décroissant par nom
int comparer_decroissant_nom(const void *a, const void *b) {
    Agent *agentA = (Agent *)a;
    Agent *agentB = (Agent *)b;
    return strcmp(agentB->nom, agentA->nom); // Comparaison inversée des noms
}

int lire_fichier_agents(const char *nom_fichier, Agent agents[], int taille_max) {
    FILE *fichier = fopen(nom_fichier, "r");
    if (!fichier) {
        perror("Erreur lors de l'ouverture du fichier");
        return -1;
    }

    int count = 0;
    while (fscanf(fichier, "%d %d %d %49s %49s %199s %199s %d-%d-%d %49s %d %19s %99s %99s %499s\n",
                  &agents[count].idagent,
                  &agents[count].idparking,
                  &agents[count].cin,
                  agents[count].nom,
                  agents[count].prenom,
                  agents[count].adresse,
                  agents[count].role,
                  &agents[count].jour,
                  &agents[count].mois,
                  &agents[count].annee,
                  agents[count].sexe,
                  &agents[count].tel,
                  agents[count].exp,
                  agents[count].statut,
                  agents[count].email,
                  agents[count].image) == 16) {
        count++;
        if (count >= taille_max) break;
    }

    fclose(fichier);
    return count;
}




