#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "operation.h"
int add_citizen(const char *filename,citizen *citizen_data)
{
 FILE *file = fopen(filename, "a");
    if (!file) {
        perror("Error opening file");
        return -1;
    }

    fprintf(file, "%d %s %s %s %s %s %s %.2f %s %s %s\n",
            citizen_data->id, citizen_data->name, citizen_data->surname,
            citizen_data->email, citizen_data->password, citizen_data->car_brand,
            citizen_data->car_serial, citizen_data->balance,
            citizen_data->color, citizen_data->gender,citizen_data->profile_picture);

    fclose(file);
    return 1;

}
int read_citizen_profile(const char *filename, citizen *citizen_data) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        return -1;
    }

    if (fscanf(file, "%d %s %s %s %s %s %s %f %s %s %s",
               &citizen_data->id, citizen_data->name, citizen_data->surname,
               citizen_data->email, citizen_data->password, citizen_data->car_brand,
               citizen_data->car_serial, &citizen_data->balance,
               citizen_data->color, citizen_data->gender,citizen_data->profile_picture) != 11) {
        fclose(file);
        return -2; 
    }

    fclose(file);
    return 0;
}

int search_citizen_by_id(const char *filename, int id_to_search, citizen *citizen_data) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        return -1;
    }

    while (fscanf(file, "%d %s %s %s %s %s %s %f %s",
                  &citizen_data->id, citizen_data->name, citizen_data->surname,
                  citizen_data->email, citizen_data->password, citizen_data->car_brand,
                  citizen_data->car_serial, &citizen_data->balance, citizen_data->color) == 9) {
        if (citizen_data->id == id_to_search) {
            fclose(file);
            return 0; // Found
        }
    }

    fclose(file);
    return -2; // Not found
}

int delete_citizen_profile(const char *filename, int id_to_delete) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        return -1;
    }

    FILE *temp_file = fopen("temp.txt", "a");
    if (!temp_file) {
        perror("Error opening temporary file");
        fclose(file);
        return -1;
    }

    int id;
    char name[50], surname[50], email[100], password[50];
    char car_brand[50], car_serial[50], color[50];
    float balance;
    int found = 0;

    // Read each line and copy to temp file if ID doesn't match
    while (fscanf(file, "%d %s %s %s %s %s %s %f %s\n",
                  &id, name, surname, email, password, car_brand,
                  car_serial, &balance, color) == 9) {
        if (id == id_to_delete) {
            found = 1; // Mark ID as found
            continue;  // Skip writing this line to the temp file
        }
        fprintf(temp_file, "%d %s %s %s %s %s %s %.2f %s\n",
                id, name, surname, email, password, car_brand,
                car_serial, balance, color);
    }

    fclose(file);
    fclose(temp_file);

    // Replace the original file with the temp file
    if (found) {
        remove(filename);
        rename("temp.txt", filename);
        return 0; // Success
    } else {
        remove("temp.txt");
        return -2; // ID not found
    }
}


int update_citizen_profile(const char *filename, const citizen *citizen_data) {
    FILE *file = fopen(filename, "a");
    if (!file) {
        perror("Error opening file");
        return -1;
    }

    fprintf(file, "%d %s %s %s %s %s %s %.2f %s %s %s\n",
            citizen_data->id, citizen_data->name, citizen_data->surname,
            citizen_data->email, citizen_data->password, citizen_data->car_brand,
            citizen_data->car_serial, citizen_data->balance,
            citizen_data->color, citizen_data->gender,citizen_data->profile_picture);

    fclose(file);
    return 0;
}
int read_parking_data(const char *filename, parking_data *data_array, int max_entries)
{
    FILE *file = fopen(filename, "r");
    if (!file) {
        return -1; // Indicate failure
    }

    int count = 0;
    while (count < max_entries && fscanf(file, "%49s %49s %f", 
                                         data_array[count].duration, 
                                         data_array[count].date, 
                                         &data_array[count].cost) == 3) {
        count++;
    }

    fclose(file);
    return count; // Return the number of records read
}

int search_all_citizens_by_id(const char *filename, int id_to_search, citizen *citizen_data_array, int max_results) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        return -1; // Unable to open file
    }

    int found_count = 0;
    while (fscanf(file, "%d %s %s %s %s %s %s %f %s %s %s\n",
                   &citizen_data_array[found_count].id,
                   citizen_data_array[found_count].name,
                   citizen_data_array[found_count].surname,
                   citizen_data_array[found_count].email,
  citizen_data_array[found_count].password,
                   citizen_data_array[found_count].car_brand,
                   citizen_data_array[found_count].car_serial,
  &citizen_data_array[found_count].balance,
  citizen_data_array[found_count].color,
  citizen_data_array[found_count].gender,
  citizen_data_array[found_count].profile_picture
                   ) != EOF) {
        if (citizen_data_array[found_count].id == id_to_search) {
            found_count++;
            if (found_count >= max_results) {
                break; // Stop if max results are found
            }
        }
    }
   
    fclose(file);

    if (found_count == 0) {
        return 0; // No citizen found
    }

    return found_count; // Return number of found citizens
}

int read_citizen_profile_by_id(const char *filename, int id_to_search, citizen *citizen_data) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        return -1; // Error opening the file
    }

    while (fscanf(file, "%d %s %s %s %s %s %s %f %s %s %s\n",
                   &citizen_data->id, citizen_data->name, citizen_data->surname,
               citizen_data->email, citizen_data->password, citizen_data->car_brand,
               citizen_data->car_serial, &citizen_data->balance,
               citizen_data->color, citizen_data->gender,citizen_data->profile_picture) != EOF) {
        if (citizen_data->id == id_to_search) {
            fclose(file);
            return 1; // Found the citizen
        }
    }

    fclose(file);
    return 0; // No citizen found
}



